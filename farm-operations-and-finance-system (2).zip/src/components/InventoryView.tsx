import React, { useState } from 'react';
import { Plus, Trash2, Search } from 'lucide-react';
import { Item, Department } from '../types';

interface InventoryViewProps {
  items: Item[];
  departments: Department[];
  addItem: (item: Omit<Item, 'id'>) => void;
  deleteItem: (id: string) => void;
  isAdding: boolean;
  setIsAdding: (val: boolean) => void;
  isAdmin: boolean;
}

const InventoryView: React.FC<InventoryViewProps> = ({ 
  items, departments, addItem, deleteItem, isAdding, setIsAdding, isAdmin 
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [newItem, setNewItem] = useState<Omit<Item, 'id'>>({
    name: '',
    category: '',
    quantity: 0,
    unit: 'pcs',
    costPrice: 0,
    sellingPrice: 0,
    departmentId: departments[0]?.id || ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addItem(newItem);
    setIsAdding(false);
    setNewItem({
      name: '',
      category: '',
      quantity: 0,
      unit: 'pcs',
      costPrice: 0,
      sellingPrice: 0,
      departmentId: departments[0]?.id || ''
    });
  };

  const filteredItems = items.filter(item => 
    item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div className="relative w-96">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            type="text" 
            placeholder="Search inventory..."
            className="w-full pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <button 
          onClick={() => setIsAdding(true)}
          className="bg-emerald-600 hover:bg-emerald-700 text-white px-6 py-2 rounded-xl flex items-center gap-2 font-medium transition-all shadow-sm"
        >
          <Plus size={18} />
          Add New Item
        </button>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-x-auto">
        <table className="w-full text-left border-collapse min-w-[800px]">
          <thead>
            <tr className="bg-slate-50/50 border-b border-slate-200">
              <th className="px-6 py-4 text-sm font-semibold text-slate-600">Item Name</th>
              <th className="px-6 py-4 text-sm font-semibold text-slate-600">Category</th>
              <th className="px-6 py-4 text-sm font-semibold text-slate-600">Stock Level</th>
              <th className="px-6 py-4 text-sm font-semibold text-slate-600">Cost Price</th>
              <th className="px-6 py-4 text-sm font-semibold text-slate-600">Sell Price</th>
              <th className="px-6 py-4 text-sm font-semibold text-slate-600 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filteredItems.map(item => (
              <tr key={item.id} className="hover:bg-slate-50/50 transition-colors">
                <td className="px-6 py-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-slate-100 overflow-hidden border border-slate-200 shrink-0">
                      <img 
                        src={`https://images.unsplash.com/photo-1589923188900-85dae523342b?auto=format&fit=crop&w=100&q=80&sig=${item.name}`} 
                        alt={item.name}
                        className="w-full h-full object-cover"
                        onError={(e) => (e.currentTarget.src = 'https://images.unsplash.com/photo-1589923188900-85dae523342b?auto=format&fit=crop&w=100&q=80')}
                      />
                    </div>
                    <div>
                      <div className="font-bold text-slate-800 leading-none mb-1">{item.name}</div>
                      <div className="text-[10px] font-black uppercase text-emerald-600 tracking-wider">
                        {departments.find(d => d.id === item.departmentId)?.name}
                      </div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 text-sm text-slate-600">{item.category}</td>
                <td className="px-6 py-4">
                  <span className={`px-2.5 py-1 rounded-full text-xs font-semibold ${
                    item.quantity < 10 ? 'bg-rose-100 text-rose-600' : 'bg-emerald-100 text-emerald-600'
                  }`}>
                    {item.quantity} {item.unit}
                  </span>
                </td>
                <td className="px-6 py-4 text-sm text-slate-600 font-medium">${item.costPrice}</td>
                <td className="px-6 py-4 text-sm text-emerald-600 font-bold">${item.sellingPrice}</td>
                <td className="px-6 py-4 text-right">
                  {isAdmin ? (
                    <button 
                      onClick={() => deleteItem(item.id)}
                      className="p-2 text-slate-400 hover:text-rose-500 transition-colors"
                    >
                      <Trash2 size={18} />
                    </button>
                  ) : (
                    <span title="Only admin can delete" className="p-2 text-slate-200 cursor-not-allowed">
                      <Trash2 size={18} />
                    </span>
                  )}
                </td>
              </tr>
            ))}
            {filteredItems.length === 0 && (
              <tr>
                <td colSpan={6} className="px-6 py-12 text-center text-slate-400 italic">
                  No items found in inventory.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {isAdding && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden animate-in fade-in zoom-in duration-200">
            <div className="p-8 border-b border-slate-100">
              <h3 className="text-xl font-bold text-slate-800">Add New Inventory Item</h3>
              <p className="text-sm text-slate-500 mt-1">Fill in the details for the new farm item.</p>
            </div>
            <form onSubmit={handleSubmit} className="p-8 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2 space-y-1.5">
                  <label className="text-sm font-semibold text-slate-700">Item Name</label>
                  <input 
                    required
                    className="w-full px-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-none transition-all"
                    value={newItem.name}
                    onChange={e => setNewItem({...newItem, name: e.target.value})}
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-semibold text-slate-700">Category</label>
                  <input 
                    required
                    className="w-full px-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-none transition-all"
                    value={newItem.category}
                    onChange={e => setNewItem({...newItem, category: e.target.value})}
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-semibold text-slate-700">Department</label>
                  <select 
                    className="w-full px-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-none transition-all"
                    value={newItem.departmentId}
                    onChange={e => setNewItem({...newItem, departmentId: e.target.value})}
                  >
                    {departments.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
                  </select>
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-semibold text-slate-700">Quantity</label>
                  <input 
                    type="number"
                    required
                    className="w-full px-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-none transition-all"
                    value={newItem.quantity}
                    onChange={e => setNewItem({...newItem, quantity: Number(e.target.value)})}
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-semibold text-slate-700">Unit (e.g. kg, pcs)</label>
                  <input 
                    required
                    className="w-full px-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-none transition-all"
                    value={newItem.unit}
                    onChange={e => setNewItem({...newItem, unit: e.target.value})}
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-semibold text-slate-700">Cost Price ($)</label>
                  <input 
                    type="number"
                    required
                    className="w-full px-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-none transition-all"
                    value={newItem.costPrice}
                    onChange={e => setNewItem({...newItem, costPrice: Number(e.target.value)})}
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-semibold text-slate-700">Sell Price ($)</label>
                  <input 
                    type="number"
                    required
                    className="w-full px-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-none transition-all"
                    value={newItem.sellingPrice}
                    onChange={e => setNewItem({...newItem, sellingPrice: Number(e.target.value)})}
                  />
                </div>
              </div>
              <div className="flex gap-4 pt-6">
                <button 
                  type="button"
                  onClick={() => setIsAdding(false)}
                  className="flex-1 px-6 py-2 border border-slate-200 text-slate-600 rounded-xl font-medium hover:bg-slate-50 transition-all"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  className="flex-1 px-6 py-2 bg-emerald-600 text-white rounded-xl font-medium hover:bg-emerald-700 transition-all"
                >
                  Save Item
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default InventoryView;
