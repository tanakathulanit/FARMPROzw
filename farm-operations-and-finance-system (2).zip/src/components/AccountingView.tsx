import React, { useState } from 'react';
import { Printer, FileText, Landmark, BarChart3, ListChecks, Database } from 'lucide-react';
import { LedgerEntry, Asset, Sale, Expense, Item } from '../types';
import { format } from 'date-fns';
import { printFinancialStatement } from '../utils/pdfGenerator';
import { generateFinancialCSV } from '../utils/csvGenerator';

import { FarmProfile } from '../types';

interface AccountingViewProps {
  ledger: LedgerEntry[];
  assets: Asset[];
  sales: Sale[];
  expenses: Expense[];
  items: Item[];
  farmProfile: FarmProfile;
  addAsset: (asset: Omit<Asset, 'id'>) => void;
}

const AccountingView: React.FC<AccountingViewProps> = ({ ledger, assets, sales, expenses, items, farmProfile, addAsset }) => {
  const [activeStatement, setActiveStatement] = useState<'balance-sheet' | 'p-and-l' | 'trial-balance' | 'ledger' | 'asset-register'>('p-and-l');

  const totalRevenue = ledger.filter(e => e.accountCategory === 'Revenue').reduce((a, c) => a + c.credit - c.debit, 0);
  const totalExpenses = ledger.filter(e => e.accountCategory === 'Expense').reduce((a, c) => a + c.debit - c.credit, 0);
  const netProfit = totalRevenue - totalExpenses;

  return (
    <div className="space-y-8">
      {/* Statement Switcher */}
      <div className="flex overflow-x-auto gap-4 pb-2 scrollbar-hide">
        {[
          { id: 'p-and-l', label: 'Profit & Loss', icon: BarChart3 },
          { id: 'balance-sheet', label: 'Balance Sheet', icon: Landmark },
          { id: 'trial-balance', label: 'Trial Balance', icon: ListChecks },
          { id: 'ledger', label: 'General Ledger', icon: Database },
          { id: 'asset-register', label: 'Asset Register', icon: FileText },
        ].map(s => (
          <button
            key={s.id}
            onClick={() => setActiveStatement(s.id as any)}
            className={`flex items-center gap-2 px-6 py-3 rounded-2xl font-black text-sm transition-all shrink-0 ${
              activeStatement === s.id ? 'bg-emerald-600 text-white shadow-lg' : 'bg-white text-slate-500 border border-slate-100 hover:bg-slate-50'
            }`}
          >
            <s.icon size={18} /> {s.label}
          </button>
        ))}
      </div>

      <div className="bg-white rounded-[40px] border border-slate-100 shadow-xl overflow-hidden min-h-[600px]">
        {/* Statement Header */}
        <header className="p-10 border-b border-slate-50 bg-slate-50/30 flex justify-between items-center">
          <div>
            <h2 className="text-3xl font-black text-slate-800 uppercase tracking-tighter">
              {activeStatement.replace('-', ' ')}
            </h2>
            <p className="text-slate-400 font-bold text-xs mt-1">FOR THE PERIOD ENDED {format(new Date(), 'dd MMMM yyyy')}</p>
          </div>
          <button 
            onClick={() => {
              generateFinancialCSV(sales, expenses, items, [], ledger);
            }}
            className="flex items-center gap-2 bg-emerald-600 text-white px-6 py-3 rounded-2xl text-sm font-black hover:bg-emerald-700 transition-all shadow-lg"
          >
            <FileText size={18} /> Export Full Financials (Excel)
          </button>
        </header>

        <div className="p-10">
          {activeStatement === 'p-and-l' && (
            <div className="max-w-3xl mx-auto space-y-12">
              <section className="space-y-4">
                <h3 className="text-xs font-black text-emerald-600 uppercase tracking-widest border-b border-emerald-100 pb-2">Revenue</h3>
                <div className="flex justify-between items-end">
                  <span className="font-bold text-slate-700">Gross Sales Revenue</span>
                  <div className="border-b border-dotted border-slate-300 flex-1 mx-4 h-0.5 mb-1"></div>
                  <span className="font-black text-slate-900">${totalRevenue.toLocaleString()}</span>
                </div>
              </section>

              <section className="space-y-4">
                <h3 className="text-xs font-black text-rose-600 uppercase tracking-widest border-b border-rose-100 pb-2">Operational Expenses</h3>
                <div className="space-y-3">
                  {Array.from(new Set(ledger.filter(e => e.accountCategory === 'Expense').map(e => e.accountName))).map(acc => {
                    const amt = ledger.filter(e => e.accountName === acc).reduce((a,c) => a + c.debit - c.credit, 0);
                    return (
                      <div key={acc} className="flex justify-between items-end italic text-sm">
                        <span className="text-slate-500">{acc}</span>
                        <div className="border-b border-slate-100 flex-1 mx-4 h-0.5 mb-1 opacity-50"></div>
                        <span className="font-bold text-slate-700">(${amt.toLocaleString()})</span>
                      </div>
                    );
                  })}
                  <div className="flex justify-between items-end pt-4 border-t border-slate-100">
                    <span className="font-black text-slate-400 uppercase text-[10px]">Total Expenses</span>
                    <span className="font-black text-slate-900 border-b-2 border-slate-900">${totalExpenses.toLocaleString()}</span>
                  </div>
                </div>
              </section>

              <div className="bg-slate-900 p-8 rounded-3xl flex justify-between items-center text-white">
                <span className="text-xl font-black uppercase tracking-widest">Net Trading Profit</span>
                <span className={`text-3xl font-black ${netProfit >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  ${netProfit.toLocaleString()}
                </span>
              </div>
            </div>
          )}

          {activeStatement === 'trial-balance' && (
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200">
                  <th className="py-4 text-left font-black text-slate-400 uppercase text-[10px]">Account Name</th>
                  <th className="py-4 text-right font-black text-slate-400 uppercase text-[10px] w-32">Debit ($)</th>
                  <th className="py-4 text-right font-black text-slate-400 uppercase text-[10px] w-32">Credit ($)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {Array.from(new Set(ledger.map(e => e.accountName))).map(acc => {
                  const debits = ledger.filter(e => e.accountName === acc).reduce((a,c) => a + c.debit, 0);
                  const credits = ledger.filter(e => e.accountName === acc).reduce((a,c) => a + c.credit, 0);
                  return (
                    <tr key={acc} className="hover:bg-slate-50/50">
                      <td className="py-4 font-bold text-slate-700">{acc}</td>
                      <td className="py-4 text-right font-mono">{debits > 0 ? debits.toLocaleString() : '-'}</td>
                      <td className="py-4 text-right font-mono">{credits > 0 ? credits.toLocaleString() : '-'}</td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot>
                <tr className="border-t-4 border-double border-slate-900 bg-slate-50">
                  <td className="py-6 font-black uppercase text-slate-900">Total</td>
                  <td className="py-6 text-right font-black text-slate-900">${ledger.reduce((a,c) => a+c.debit, 0).toLocaleString()}</td>
                  <td className="py-6 text-right font-black text-slate-900">${ledger.reduce((a,c) => a+c.credit, 0).toLocaleString()}</td>
                </tr>
              </tfoot>
            </table>
          )}

          {activeStatement === 'ledger' && (
             <div className="overflow-x-auto">
               <table className="w-full text-sm">
                <thead className="bg-slate-50">
                  <tr>
                    <th className="p-4 text-left font-black uppercase text-[10px] text-slate-400">Date</th>
                    <th className="p-4 text-left font-black uppercase text-[10px] text-slate-400">Description</th>
                    <th className="p-4 text-left font-black uppercase text-[10px] text-slate-400">Account</th>
                    <th className="p-4 text-right font-black uppercase text-[10px] text-slate-400">Debit</th>
                    <th className="p-4 text-right font-black uppercase text-[10px] text-slate-400">Credit</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {ledger.map(e => (
                    <tr key={e.id} className="hover:bg-slate-50/50">
                      <td className="p-4 text-slate-500">{format(new Date(e.date), 'dd/MM/yyyy')}</td>
                      <td className="p-4 font-medium text-slate-700">{e.description}</td>
                      <td className="p-4 font-bold text-emerald-600">{e.accountName}</td>
                      <td className="p-4 text-right font-mono">{e.debit > 0 ? e.debit.toLocaleString() : '-'}</td>
                      <td className="p-4 text-right font-mono">{e.credit > 0 ? e.credit.toLocaleString() : '-'}</td>
                    </tr>
                  ))}
                </tbody>
               </table>
             </div>
          )}

          {activeStatement === 'asset-register' && (
             <div className="space-y-6">
                <div className="flex justify-end">
                   <button 
                     onClick={() => {
                        const name = prompt('Asset Name');
                        const cost = Number(prompt('Cost Value ($)') || 0);
                        const depr = Number(prompt('Depreciation Rate (%)') || 10);
                        const cat = prompt('Category (Land, Buildings, Machinery, Livestock, Vehicles)') as any;
                        if(name && cost && cat) {
                           addAsset({ name, costValue: cost, depreciationRate: depr, category: cat, purchaseDate: new Date().toISOString(), accumulatedDepreciation: 0, netBookValue: cost, status: 'active', departmentId: '1', code: 'AST-'+Math.random().toString(36).substr(2,4).toUpperCase() });
                        }
                     }}
                     className="bg-emerald-600 text-white px-6 py-2 rounded-xl font-black text-xs shadow-lg hover:bg-emerald-700 transition-all"
                   >
                     + Register New Asset
                   </button>
                </div>
                <div className="overflow-x-auto">
                   <table className="w-full text-sm min-w-[800px]">
                    <thead className="bg-slate-900 text-white">
                      <tr>
                        <th className="p-4 text-left font-black uppercase text-[9px]">Asset Code</th>
                        <th className="p-4 text-left font-black uppercase text-[9px]">Description</th>
                        <th className="p-4 text-left font-black uppercase text-[9px]">Acquisition</th>
                        <th className="p-4 text-right font-black uppercase text-[9px]">Cost</th>
                        <th className="p-4 text-right font-black uppercase text-[9px]">Depr %</th>
                        <th className="p-4 text-right font-black uppercase text-[9px]">NBV</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {assets.map(a => (
                        <tr key={a.id} className="hover:bg-slate-50/50">
                          <td className="p-4 font-mono font-bold text-emerald-600">{a.code}</td>
                          <td className="p-4 font-bold text-slate-800">{a.name} <span className="block text-[9px] text-slate-400 uppercase tracking-widest">{a.category}</span></td>
                          <td className="p-4 text-slate-500">{format(new Date(a.purchaseDate), 'dd MMM yyyy')}</td>
                          <td className="p-4 text-right font-black">${a.costValue.toLocaleString()}</td>
                          <td className="p-4 text-right text-rose-500 font-bold">{a.depreciationRate}%</td>
                          <td className="p-4 text-right font-black text-emerald-600">${a.netBookValue.toLocaleString()}</td>
                        </tr>
                      ))}
                    </tbody>
                   </table>
                </div>
             </div>
          )}

          {activeStatement === 'balance-sheet' && (
            <div className="max-w-3xl mx-auto space-y-12">
               <section className="space-y-4">
                  <h3 className="text-xl font-black text-slate-800 border-b-4 border-emerald-500 pb-2 inline-block">ASSETS</h3>
                  <div className="space-y-6 pt-4">
                     <h4 className="text-[10px] font-black uppercase text-slate-400 tracking-[0.3em]">Non-Current Assets</h4>
                     <div className="flex justify-between items-center italic">
                        <span>Property, Plant & Equipment (PPE)</span>
                        <span className="font-black text-slate-900">${assets.reduce((a,c) => a + (c.netBookValue || c.costValue), 0).toLocaleString()}</span>
                     </div>
                     <h4 className="text-[10px] font-black uppercase text-slate-400 tracking-[0.3em]">Current Assets</h4>
                     <div className="flex justify-between items-center italic">
                        <span>Inventory & Biological Assets</span>
                        <span className="font-black text-slate-900">${items.reduce((a,c) => a + (c.quantity * c.costPrice), 0).toLocaleString()}</span>
                     </div>
                     <div className="flex justify-between items-center italic">
                        <span>Cash and Cash Equivalents</span>
                        <span className="font-black text-slate-900">${(totalRevenue - totalExpenses).toLocaleString()}</span>
                     </div>
                  </div>
               </section>
               <div className="bg-slate-900 h-1"></div>
               <section className="space-y-4 text-right">
                  <span className="text-[10px] font-black uppercase text-slate-400 tracking-[0.3em]">Total Assets Managed</span>
                  <div className="text-4xl font-black text-slate-900">
                    ${(assets.reduce((a,c) => a + (c.netBookValue || c.costValue), 0) + items.reduce((a,c) => a + (c.quantity * c.costPrice), 0) + (totalRevenue - totalExpenses)).toLocaleString()}
                  </div>
               </section>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AccountingView;
