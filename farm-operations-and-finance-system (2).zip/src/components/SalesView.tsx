import React, { useState } from 'react';
import { Plus, Trash2, Printer, ShoppingCart, Package } from 'lucide-react';
import { Sale, Item, Department, SaleItem, User, FarmProfile } from '../types';
import { format } from 'date-fns';
import { generateReceipt } from '../utils/pdfGenerator';
import { initiatePaynowPayment } from '../utils/apiServices';
import { Smartphone, Banknote, RefreshCw } from 'lucide-react';

interface SalesViewProps {
  sales: Sale[];
  items: Item[];
  departments: Department[];
  currentUser: User | null;
  farmProfile: FarmProfile;
  addSale: (sale: Omit<Sale, 'id'>) => any;
  deleteSale: (id: string) => void;
  isAdding: boolean;
  setIsAdding: (val: boolean) => void;
  isAdmin: boolean;
}

const SalesView: React.FC<SalesViewProps> = ({ 
  sales, items, departments, currentUser, farmProfile, addSale, deleteSale, isAdding, setIsAdding, isAdmin 
}) => {
  const [cart, setCart] = useState<SaleItem[]>([]);
  const [selectedDeptId, setSelectedDeptId] = useState(departments[0]?.id || '');
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'electronic'>('cash');
  const [isProcessing, setIsProcessing] = useState(false);
  const [customerPhone, setPhone] = useState('');
  
  const [currentItem, setCurrentItem] = useState({
    itemId: '',
    quantity: 1
  });

  const addToCart = () => {
    const item = items.find(i => i.id === currentItem.itemId);
    if (!item) return;
    if (item.quantity < currentItem.quantity) {
      alert('Not enough stock!');
      return;
    }

    const existing = cart.find(c => c.itemId === item.id);
    if (existing) {
      setCart(cart.map(c => c.itemId === item.id ? {
        ...c, 
        quantity: c.quantity + currentItem.quantity,
        total: (c.quantity + currentItem.quantity) * c.price
      } : c));
    } else {
      setCart([...cart, {
        itemId: item.id,
        itemName: item.name,
        quantity: currentItem.quantity,
        price: item.sellingPrice,
        total: item.sellingPrice * currentItem.quantity
      }]);
    }
  };

  const removeFromCart = (id: string) => {
    setCart(cart.filter(c => c.itemId !== id));
  };

  const cartTotal = cart.reduce((acc, curr) => acc + curr.total, 0);

  const handleConfirmSale = async () => {
    if (cart.length === 0 || !currentUser) return;

    setIsProcessing(true);
    
    // Electronic Payment Flow (Paynow)
    if (paymentMethod === 'electronic') {
      try {
        const payment = await initiatePaynowPayment(cartTotal, 'customer@farmpro.com', `SALE-${Date.now()}`, customerPhone) as any;
        if (payment.success) {
          // In a real system, you would show the redirect or wait for status change
          alert(`Electronic Payment Initiated. Please check phone ${customerPhone} for PIN prompt.`);
        }
      } catch (err) {
        alert('Payment processing failed.');
        setIsProcessing(false);
        return;
      }
    }

    const saleData: Omit<Sale, 'id'> = {
      items: cart,
      total: cartTotal,
      date: new Date().toISOString(),
      departmentId: selectedDeptId,
      userId: currentUser.id,
      userName: currentUser.name
    };

    const result = addSale(saleData);
    if (result) {
      generateReceipt(result, farmProfile);
      setCart([]);
      setIsAdding(false);
    }
    setIsProcessing(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold text-slate-800">Multi-Item Sales Point</h2>
        <button 
          onClick={() => setIsAdding(true)}
          className="bg-emerald-600 hover:bg-emerald-700 text-white px-6 py-2 rounded-xl flex items-center gap-2 font-medium transition-all shadow-sm"
        >
          <Plus size={18} />
          Record New Multi-Sale
        </button>
      </div>

      {/* History Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-x-auto">
        <table className="w-full text-left border-collapse min-w-[900px]">
          <thead>
            <tr className="bg-slate-50/50 border-b border-slate-200">
              <th className="px-6 py-4 text-sm font-semibold text-slate-600">Date</th>
              <th className="px-6 py-4 text-sm font-semibold text-slate-600">Receipt ID</th>
              <th className="px-6 py-4 text-sm font-semibold text-slate-600">Items</th>
              <th className="px-6 py-4 text-sm font-semibold text-slate-600">Total</th>
              <th className="px-6 py-4 text-sm font-semibold text-slate-600">Staff</th>
              <th className="px-6 py-4 text-sm font-semibold text-slate-600 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {[...sales].reverse().map(sale => (
              <tr key={sale.id} className="hover:bg-slate-50/50 transition-colors">
                <td className="px-6 py-4 text-sm text-slate-500">
                  {format(new Date(sale.date), 'MMM dd, HH:mm')}
                </td>
                <td className="px-6 py-4 font-mono text-xs font-bold text-slate-400">
                  #{sale.id.slice(-6).toUpperCase()}
                </td>
                <td className="px-6 py-4 text-sm text-slate-600">
                  {sale.items.length} items
                </td>
                <td className="px-6 py-4 text-sm font-bold text-emerald-600">${sale.total}</td>
                <td className="px-6 py-4 text-xs font-bold text-slate-500">{sale.userName}</td>
                <td className="px-6 py-4 text-right flex justify-end gap-2">
                  <button 
                    onClick={() => generateReceipt(sale, farmProfile)}
                    className="p-2 text-slate-400 hover:text-emerald-500 transition-all active:scale-95"
                  >
                    <Printer size={18} />
                  </button>
                  {isAdmin && (
                    <button 
                      onClick={() => deleteSale(sale.id)}
                      className="p-2 text-slate-400 hover:text-rose-500 transition-colors"
                    >
                      <Trash2 size={18} />
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {isAdding && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-4xl overflow-hidden flex h-[600px] animate-in fade-in zoom-in duration-200">
            {/* Left: Product Selector */}
            <div className="w-1/2 p-8 border-r border-slate-100 flex flex-col">
              <h3 className="text-xl font-bold text-slate-800 mb-6 flex items-center gap-2">
                <ShoppingCart className="text-emerald-600" /> POS Cart Builder
              </h3>
              
              <div className="space-y-4 flex-1">
                <div className="space-y-1.5">
                  <label className="text-xs font-black text-slate-400 uppercase">Department</label>
                  <select 
                    className="w-full px-4 py-2 rounded-xl border border-slate-200"
                    value={selectedDeptId}
                    onChange={e => setSelectedDeptId(e.target.value)}
                  >
                    {departments.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-black text-slate-400 uppercase">Select Product</label>
                  <div className="grid grid-cols-1 gap-2 max-h-[250px] overflow-y-auto pr-2">
                    {items.filter(i => i.departmentId === selectedDeptId && i.quantity > 0).map(i => (
                      <button
                        key={i.id}
                        onClick={() => setCurrentItem({...currentItem, itemId: i.id})}
                        className={`text-left p-3 rounded-xl border transition-all flex justify-between items-center ${
                          currentItem.itemId === i.id ? 'border-emerald-500 bg-emerald-50 ring-2 ring-emerald-500/10' : 'border-slate-100 hover:bg-slate-50'
                        }`}
                      >
                        <div>
                          <div className="font-bold text-slate-800">{i.name}</div>
                          <div className="text-[10px] text-slate-500">Stock: {i.quantity} {i.unit}</div>
                        </div>
                        <div className="font-black text-emerald-600">${i.sellingPrice}</div>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex gap-4 items-end">
                  <div className="flex-1 space-y-1.5">
                    <label className="text-xs font-black text-slate-400 uppercase">Quantity</label>
                    <input 
                      type="number"
                      min="1"
                      className="w-full px-4 py-2 rounded-xl border border-slate-200"
                      value={currentItem.quantity}
                      onChange={e => setCurrentItem({...currentItem, quantity: Number(e.target.value)})}
                    />
                  </div>
                  <button 
                    onClick={addToCart}
                    className="bg-emerald-600 text-white h-[42px] px-6 rounded-xl font-bold hover:bg-emerald-700 transition-all flex items-center gap-2"
                  >
                    <Plus size={18} /> Add
                  </button>
                </div>
              </div>
            </div>

            {/* Right: Cart Summary */}
            <div className="w-1/2 bg-slate-50 p-8 flex flex-col">
              <div className="flex justify-between items-center mb-6">
                <h4 className="font-black text-slate-500 uppercase text-xs tracking-widest">Order Summary</h4>
                <div className="text-[10px] font-bold text-emerald-600 px-2 py-0.5 bg-emerald-100 rounded-md uppercase">
                  Cash Sale
                </div>
              </div>

              <div className="flex-1 overflow-y-auto space-y-3">
                {cart.map(c => (
                  <div key={c.itemId} className="bg-white p-3 rounded-xl border border-slate-200 flex justify-between items-center group">
                    <div className="flex items-center gap-3">
                      <div className="bg-slate-100 p-2 rounded-lg text-slate-400 group-hover:bg-emerald-50 group-hover:text-emerald-500 transition-colors">
                        <Package size={14} />
                      </div>
                      <div>
                        <div className="font-bold text-sm text-slate-800">{c.itemName}</div>
                        <div className="text-[10px] text-slate-500">{c.quantity} x ${c.price}</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="font-black text-slate-800 text-sm">${c.total}</div>
                      <button onClick={() => removeFromCart(c.itemId)} className="text-slate-300 hover:text-rose-500">
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-6 pt-6 border-t border-slate-200 space-y-4">
                <div className="space-y-3">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Payment Mode</label>
                  <div className="grid grid-cols-2 gap-3">
                    <button 
                      onClick={() => setPaymentMethod('cash')}
                      className={`py-3 rounded-xl border-2 flex items-center justify-center gap-2 transition-all font-bold text-sm ${paymentMethod === 'cash' ? 'border-emerald-500 bg-emerald-50 text-emerald-700' : 'border-slate-100 bg-white text-slate-400'}`}
                    >
                      <Banknote size={16} /> Cash
                    </button>
                    <button 
                      onClick={() => setPaymentMethod('electronic')}
                      className={`py-3 rounded-xl border-2 flex items-center justify-center gap-2 transition-all font-bold text-sm ${paymentMethod === 'electronic' ? 'border-emerald-500 bg-emerald-50 text-emerald-700' : 'border-slate-100 bg-white text-slate-400'}`}
                    >
                      <Smartphone size={16} /> Electronic
                    </button>
                  </div>
                </div>

                {paymentMethod === 'electronic' && (
                  <div className="space-y-1.5 animate-in fade-in slide-in-from-top-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Customer Phone (EcoCash/InBucks)</label>
                    <input 
                      type="text"
                      placeholder="e.g. 0771234567"
                      className="w-full px-4 py-2 rounded-xl border-2 border-emerald-100 outline-none focus:border-emerald-500 font-bold"
                      value={customerPhone}
                      onChange={e => setPhone(e.target.value)}
                    />
                  </div>
                )}

                <div className="flex justify-between items-center py-2 border-y border-slate-100">
                  <span className="font-bold text-slate-500">Order Total</span>
                  <span className="font-black text-slate-800 text-3xl">${cartTotal}</span>
                </div>

                <div className="flex gap-4">
                  <button 
                    onClick={() => setIsAdding(false)}
                    disabled={isProcessing}
                    className="flex-1 py-4 bg-white border border-slate-200 rounded-2xl font-bold text-slate-500 hover:bg-slate-100 transition-all"
                  >
                    Cancel
                  </button>
                  <button 
                    onClick={handleConfirmSale}
                    disabled={cart.length === 0 || isProcessing}
                    className="flex-[2] py-4 bg-emerald-600 text-white rounded-2xl font-black shadow-xl shadow-emerald-900/30 hover:bg-emerald-700 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {isProcessing ? <RefreshCw className="animate-spin" size={20} /> : 'CONFIRM & PRINT'}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SalesView;
