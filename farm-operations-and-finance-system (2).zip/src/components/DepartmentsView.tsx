import React, { useState } from 'react';
import { Plus, Building2, ChevronRight, Package, ShoppingCart, Receipt } from 'lucide-react';
import { Department, Item, Sale, Expense } from '../types';

interface DepartmentsViewProps {
  departments: Department[];
  items: Item[];
  sales: Sale[];
  expenses: Expense[];
  addDepartment: (name: string) => void;
  isAdding: boolean;
  setIsAdding: (val: boolean) => void;
}

const DepartmentsView: React.FC<DepartmentsViewProps> = ({ 
  departments, items, sales, expenses, addDepartment, isAdding, setIsAdding 
}) => {
  const [newDeptName, setNewDeptName] = useState('');
  const [selectedDeptId, setSelectedDeptId] = useState<string | null>(null);

  const selectedDept = departments.find(d => d.id === selectedDeptId);
  const deptItems = items.filter(i => i.departmentId === selectedDeptId);
  const deptSales = sales.filter(s => s.departmentId === selectedDeptId);
  const deptExpenses = expenses.filter(e => e.departmentId === selectedDeptId);

  const totalDeptSales = deptSales.reduce((acc, curr) => acc + curr.total, 0);
  const totalDeptExpenses = deptExpenses.reduce((acc, curr) => acc + curr.amount, 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newDeptName.trim()) {
      addDepartment(newDeptName.trim());
      setNewDeptName('');
      setIsAdding(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold text-slate-800">Farm Departments</h2>
        <button 
          onClick={() => setIsAdding(true)}
          className="bg-emerald-600 hover:bg-emerald-700 text-white px-6 py-2 rounded-xl flex items-center gap-2 font-medium transition-all shadow-sm"
        >
          <Plus size={18} />
          Create New Department
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {departments.map(dept => (
          <button 
            key={dept.id} 
            onClick={() => setSelectedDeptId(dept.id)}
            className="text-left bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-all group"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="bg-emerald-50 p-3 rounded-xl text-emerald-600 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                <Building2 size={24} />
              </div>
              <ChevronRight className="text-slate-300 group-hover:text-emerald-500 transition-colors" size={20} />
            </div>
            <h3 className="text-lg font-bold text-slate-800">{dept.name}</h3>
            <p className="text-sm text-slate-500 mt-1">
              {items.filter(i => i.departmentId === dept.id).length} Items Registered
            </p>
            
            <div className="mt-6 pt-6 border-t border-slate-50 flex items-center gap-4 text-xs font-semibold text-slate-400">
               <span>ACTIVE UNIT</span>
               <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
            </div>
          </button>
        ))}
      </div>

      {/* Department Detail Overlay */}
      {selectedDept && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[60] flex items-center justify-center p-4 lg:p-12 overflow-y-auto">
          <div className="bg-slate-50 w-full max-w-6xl rounded-3xl shadow-2xl min-h-[80vh] flex flex-col relative animate-in fade-in zoom-in duration-300">
            <header className="p-8 bg-white border-b border-slate-200 rounded-t-3xl sticky top-0 z-10">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-4">
                  <div className="bg-emerald-600 p-3 rounded-2xl text-white">
                    <Building2 size={28} />
                  </div>
                  <div>
                    <h2 className="text-3xl font-black text-slate-800">{selectedDept.name}</h2>
                    <p className="text-slate-500 font-medium italic">Department Comprehensive View</p>
                  </div>
                </div>
                <button 
                  onClick={() => setSelectedDeptId(null)}
                  className="bg-slate-100 hover:bg-slate-200 p-3 rounded-2xl text-slate-600 transition-all font-bold"
                >
                  Close Explorer
                </button>
              </div>

              <div className="grid grid-cols-3 gap-6 mt-8">
                <div className="bg-emerald-50 p-4 rounded-2xl border border-emerald-100">
                  <div className="flex items-center gap-2 text-emerald-700 font-bold text-xs uppercase mb-1">
                    <ShoppingCart size={14} /> Total Sales
                  </div>
                  <div className="text-2xl font-black text-emerald-900">${totalDeptSales.toLocaleString()}</div>
                </div>
                <div className="bg-rose-50 p-4 rounded-2xl border border-rose-100">
                  <div className="flex items-center gap-2 text-rose-700 font-bold text-xs uppercase mb-1">
                    <Receipt size={14} /> Total Expenses
                  </div>
                  <div className="text-2xl font-black text-rose-900">${totalDeptExpenses.toLocaleString()}</div>
                </div>
                <div className="bg-slate-100 p-4 rounded-2xl border border-slate-200">
                  <div className="flex items-center gap-2 text-slate-600 font-bold text-xs uppercase mb-1">
                    <Package size={14} /> Items Count
                  </div>
                  <div className="text-2xl font-black text-slate-800">{deptItems.length}</div>
                </div>
              </div>
            </header>

            <div className="flex-1 p-8 grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Items Table */}
              <section className="space-y-4">
                <h4 className="flex items-center gap-2 text-lg font-bold text-slate-800">
                  <Package className="text-emerald-600" size={20} /> 
                  Inventory List
                </h4>
                <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
                  <table className="w-full text-sm text-left">
                    <thead className="bg-slate-50 border-b border-slate-200">
                      <tr>
                        <th className="px-4 py-3 font-bold text-slate-600 uppercase text-[10px]">Item</th>
                        <th className="px-4 py-3 font-bold text-slate-600 uppercase text-[10px]">Stock</th>
                        <th className="px-4 py-3 font-bold text-slate-600 uppercase text-[10px]">Price</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {deptItems.map(i => (
                        <tr key={i.id}>
                          <td className="px-4 py-3 font-bold text-slate-800">{i.name}</td>
                          <td className="px-4 py-3">
                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-black ${i.quantity < 5 ? 'bg-rose-100 text-rose-600' : 'bg-emerald-100 text-emerald-600'}`}>
                              {i.quantity} {i.unit}
                            </span>
                          </td>
                          <td className="px-4 py-3 font-medium text-emerald-600">${i.sellingPrice}</td>
                        </tr>
                      ))}
                      {deptItems.length === 0 && (
                        <tr><td colSpan={3} className="px-4 py-8 text-center italic text-slate-400">No items found</td></tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </section>

              {/* Transactions Tab */}
              <section className="space-y-4">
                 <h4 className="flex items-center gap-2 text-lg font-bold text-slate-800">
                  <ShoppingCart className="text-amber-600" size={20} /> 
                  Recent Sales
                </h4>
                <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm h-[300px] overflow-y-auto">
                   <table className="w-full text-sm text-left">
                    <thead className="bg-slate-50 border-b border-slate-200 sticky top-0">
                      <tr>
                        <th className="px-4 py-3 font-bold text-slate-600 uppercase text-[10px]">Order ID</th>
                        <th className="px-4 py-3 font-bold text-slate-600 uppercase text-[10px]">Items</th>
                        <th className="px-4 py-3 font-bold text-slate-600 uppercase text-[10px]">Total</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {deptSales.map(s => (
                        <tr key={s.id}>
                          <td className="px-4 py-3 font-mono text-xs">#{s.id.slice(-6).toUpperCase()}</td>
                          <td className="px-4 py-3 text-xs text-slate-600">
                            {s.items.map(i => `${i.itemName} (x${i.quantity})`).join(', ')}
                          </td>
                          <td className="px-4 py-3 font-bold text-emerald-600">${s.total}</td>
                        </tr>
                      ))}
                      {deptSales.length === 0 && (
                        <tr><td colSpan={3} className="px-4 py-8 text-center italic text-slate-400">No sales found</td></tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </section>
            </div>
          </div>
        </div>
      )}

      {isAdding && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-sm overflow-hidden animate-in fade-in zoom-in duration-200">
            <div className="p-8 border-b border-slate-100">
              <h3 className="text-xl font-bold text-slate-800">Add Department</h3>
              <p className="text-sm text-slate-500 mt-1">Enter the name of the new section.</p>
            </div>
            <form onSubmit={handleSubmit} className="p-8 space-y-4">
              <div className="space-y-1.5">
                <label className="text-sm font-semibold text-slate-700">Department Name</label>
                <input 
                  required
                  autoFocus
                  placeholder="e.g. Greenhouse A"
                  className="w-full px-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-none transition-all"
                  value={newDeptName}
                  onChange={e => setNewDeptName(e.target.value)}
                />
              </div>
              <div className="flex gap-4 pt-6">
                <button 
                  type="button"
                  onClick={() => setIsAdding(false)}
                  className="flex-1 px-6 py-2 border border-slate-200 text-slate-600 rounded-xl font-medium hover:bg-slate-50 transition-all"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  className="flex-1 px-6 py-2 bg-emerald-600 text-white rounded-xl font-medium hover:bg-emerald-700 transition-all"
                >
                  Create
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default DepartmentsView;
