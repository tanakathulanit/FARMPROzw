import React from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  PieChart as PieChartIcon,
  ArrowUpRight
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
  PieChart,
  Pie
} from 'recharts';
import { Sale, Expense } from '../types';
import { format, subDays, isSameDay } from 'date-fns';

interface DashboardViewProps {
  sales: Sale[];
  expenses: Expense[];
  totalSales: number;
  totalExpenses: number;
  profitLoss: number;
}

const COLORS = ['#10b981', '#ef4444', '#f59e0b', '#3b82f6'];

const DashboardView: React.FC<DashboardViewProps> = ({ 
  sales, 
  expenses, 
  totalSales, 
  totalExpenses, 
  profitLoss 
}) => {
  // Last 7 days chart data
  const last7Days = [...Array(7)].map((_, i) => {
    const date = subDays(new Date(), i);
    const daySales = sales
      .filter(s => isSameDay(new Date(s.date), date))
      .reduce((acc, curr) => acc + curr.total, 0);
    const dayExpenses = expenses
      .filter(e => isSameDay(new Date(e.date), date))
      .reduce((acc, curr) => acc + curr.amount, 0);
    
    return {
      name: format(date, 'MMM dd'),
      sales: daySales,
      expenses: dayExpenses,
      profit: daySales - dayExpenses
    };
  }).reverse();

  const pieData = [
    { name: 'Sales', value: totalSales },
    { name: 'Expenses', value: totalExpenses },
  ];

  return (
    <div className="space-y-8">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <div className="flex justify-between items-start mb-4">
            <div className="bg-emerald-50 p-3 rounded-xl text-emerald-600">
              <DollarSign size={24} />
            </div>
            <div className="flex items-center text-emerald-600 text-sm font-medium">
              <ArrowUpRight size={16} />
              <span>+12%</span>
            </div>
          </div>
          <h3 className="text-slate-500 text-sm font-medium">Total Sales</h3>
          <p className="text-2xl font-bold text-slate-800">${totalSales.toLocaleString()}</p>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <div className="flex justify-between items-start mb-4">
            <div className="bg-rose-50 p-3 rounded-xl text-rose-600">
              <TrendingDown size={24} />
            </div>
            <div className="flex items-center text-rose-600 text-sm font-medium">
              <ArrowUpRight size={16} />
              <span>+5%</span>
            </div>
          </div>
          <h3 className="text-slate-500 text-sm font-medium">Total Expenses</h3>
          <p className="text-2xl font-bold text-slate-800">${totalExpenses.toLocaleString()}</p>
        </div>

        <div className={`bg-white p-6 rounded-2xl shadow-sm border border-slate-100 ${profitLoss >= 0 ? 'border-l-4 border-l-emerald-500' : 'border-l-4 border-l-rose-500'}`}>
          <div className="flex justify-between items-start mb-4">
            <div className={`${profitLoss >= 0 ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'} p-3 rounded-xl`}>
              <TrendingUp size={24} />
            </div>
          </div>
          <h3 className="text-slate-500 text-sm font-medium">Net Profit/Loss</h3>
          <p className={`text-2xl font-bold ${profitLoss >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
            {profitLoss >= 0 ? '' : '-'}${Math.abs(profitLoss).toLocaleString()}
          </p>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100">
          <h3 className="text-lg font-bold text-slate-800 mb-6 flex items-center gap-2">
            <TrendingUp size={20} className="text-emerald-500" />
            Revenue vs Expenses (Last 7 Days)
          </h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={last7Days}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} />
                <Tooltip 
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Bar dataKey="sales" fill="#10b981" radius={[4, 4, 0, 0]} name="Sales" />
                <Bar dataKey="expenses" fill="#ef4444" radius={[4, 4, 0, 0]} name="Expenses" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100">
          <h3 className="text-lg font-bold text-slate-800 mb-6 flex items-center gap-2">
            <PieChartIcon size={20} className="text-amber-500" />
            Budget Overview
          </h3>
          <div className="h-80 flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {pieData.map((_, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex justify-center gap-6 mt-4">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-emerald-500"></div>
              <span className="text-sm text-slate-600">Sales</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-rose-500"></div>
              <span className="text-sm text-slate-600">Expenses</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardView;
