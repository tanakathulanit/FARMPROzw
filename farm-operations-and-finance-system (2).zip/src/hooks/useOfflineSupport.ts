import { useEffect } from 'react';

export const useOfflineSupport = () => {
  useEffect(() => {
    // Register Service Worker for PWA (Offline capability)
    if ('serviceWorker' in navigator) {
      window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js').then(registration => {
          console.log('SW registered: ', registration);
        }).catch(registrationError => {
          console.log('SW registration failed: ', registrationError);
        });
      });
    }

    // Monitor Online/Offline Status
    const handleOnline = () => {
      console.log("System back online. Syncing data...");
      // Logic for background sync would go here when moving to Firebase
    };

    const handleOffline = () => {
      console.log("System offline. Using local secure storage.");
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  return {
    isOnline: navigator.onLine
  };
};
