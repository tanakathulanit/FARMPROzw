import { useState, useEffect } from 'react';
import { Department, Item, Sale, Expense, User, Asset, Transaction, MarketProduct, GlobalUser, LedgerEntry, FarmProfile } from '../types';

export const useFarmData = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('farm_current_user');
    return saved ? JSON.parse(saved) : null;
  });

  const [farmProfile, setFarmProfile] = useState<FarmProfile>(() => {
    const saved = localStorage.getItem('farm_profile');
    return saved ? JSON.parse(saved) : {
      id: 'FARM_001',
      name: 'My Enterprise Farm ZW',
      address: 'Harare, Zimbabwe',
      contact: '+263 770 000 000',
      email: 'admin@farmpro.co.zw'
    };
  });

  const [users, setUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem('farm_users');
    return saved ? JSON.parse(saved) : [
      { 
        id: 'admin', 
        name: 'Administrator', 
        role: 'admin', 
        password: 'admin123',
        subscriptionStatus: 'active',
        subscriptionTier: 'enterprise',
        farmId: 'FARM_001',
        farmName: 'My Enterprise Farm',
        trialStartDate: new Date().toISOString()
      }
    ];
  });

  // Security Logic: Simple Hash Simulation
  const hash = (str: string) => btoa(str).split('').reverse().join('');

  const login = (userId: string, password?: string) => {
    if (!password) return false;
    const hashedInput = hash(password);
    
    // Find user by ID
    const user = users.find(u => u.id === userId);
    
    if (user) {
      // Check if password matches (either hashed or plain text for initial admin)
      const isMatch = (user.password === hashedInput) || (user.id === 'admin' && user.password === password);
      
      if (isMatch) {
        // Handle trial expiry
        if (user.subscriptionStatus === 'trial' && user.trialStartDate) {
          const start = new Date(user.trialStartDate).getTime();
          const now = Date.now();
          const diffDays = (now - start) / (1000 * 3600 * 24);
          if (diffDays > 14) {
            user.subscriptionStatus = 'expired';
          }
        }

        // Auto-upgrade plain password if it's the admin
        if (user.id === 'admin' && user.password === 'admin123' && password === 'admin123') {
           user.password = hashedInput;
        }

        setCurrentUser(user);
        localStorage.setItem('farm_current_user', JSON.stringify(user));
        localStorage.setItem('farm_user_role', user.role);
        
        // Persist the potentially updated user status in the users list
        setUsers(prev => prev.map(u => u.id === user.id ? user : u));
        
        return true;
      }
    }
    return false;
  };

  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem('farm_current_user');
    localStorage.removeItem('farm_user_role');
  };

  const registerFarm = (data: { name: string, farmName: string, email: string, pass: string }) => {
    const userId = data.email.split('@')[0] + Math.floor(Math.random() * 1000);
    const newUser: User = {
      id: userId,
      name: data.name,
      email: data.email,
      role: 'admin',
      password: hash(data.pass),
      subscriptionStatus: 'trial',
      subscriptionTier: 'free',
      farmId: 'FARM_' + Date.now(),
      farmName: data.farmName,
      trialStartDate: new Date().toISOString()
    };
    setUsers(prev => [...prev, newUser]);
    addLog('System', `New Farm Registered: ${data.farmName}`);
    return userId;
  };

  const updateUserPassword = (userId: string, newPass: string) => {
    const hashed = hash(newPass);
    setUsers(prev => prev.map(u => u.id === userId ? { ...u, password: hashed } : u));
    addLog('Security', `User ${userId} updated security credentials.`);
  };

  const userRole = currentUser?.role || 'employee';
  const isAdmin = userRole === 'admin';

  const [departments, setDepartments] = useState<Department[]>(() => {
    const saved = localStorage.getItem('farm_departments');
    return saved ? JSON.parse(saved) : [
      { id: '1', name: 'Livestock' },
      { id: '2', name: 'Crops' },
      { id: '3', name: 'Poultry' }
    ];
  });

  const [items, setItems] = useState<Item[]>(() => {
    const saved = localStorage.getItem('farm_items');
    return saved ? JSON.parse(saved) : [];
  });

  const [sales, setSales] = useState<Sale[]>(() => {
    const saved = localStorage.getItem('farm_sales');
    return saved ? JSON.parse(saved) : [];
  });

  const [expenses, setExpenses] = useState<Expense[]>(() => {
    const saved = localStorage.getItem('farm_expenses');
    return saved ? JSON.parse(saved) : [];
  });

  const [assets, setAssets] = useState<Asset[]>(() => {
    const saved = localStorage.getItem('farm_assets');
    return saved ? JSON.parse(saved) : [];
  });

  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem('farm_transactions');
    return saved ? JSON.parse(saved) : [];
  });

  const [ledger, setLedger] = useState<LedgerEntry[]>(() => {
    const saved = localStorage.getItem('farm_ledger');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => { localStorage.setItem('farm_ledger', JSON.stringify(ledger)); }, [ledger]);

  const postToLedger = (entries: Omit<LedgerEntry, 'id'>[]) => {
    const newEntries = entries.map(e => ({ ...e, id: Math.random().toString(36).substr(2, 9) }));
    setLedger(prev => [...prev, ...newEntries]);
  };

  const [auditLogs, setAuditLogs] = useState<any[]>(() => {
    const saved = localStorage.getItem('farm_audit_logs');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => { localStorage.setItem('farm_users', JSON.stringify(users)); }, [users]);
  useEffect(() => { localStorage.setItem('farm_departments', JSON.stringify(departments)); }, [departments]);
  useEffect(() => { localStorage.setItem('farm_items', JSON.stringify(items)); }, [items]);
  useEffect(() => { localStorage.setItem('farm_sales', JSON.stringify(sales)); }, [sales]);
  useEffect(() => { localStorage.setItem('farm_expenses', JSON.stringify(expenses)); }, [expenses]);
  useEffect(() => { localStorage.setItem('farm_assets', JSON.stringify(assets)); }, [assets]);
  useEffect(() => { localStorage.setItem('farm_transactions', JSON.stringify(transactions)); }, [transactions]);
  useEffect(() => { localStorage.setItem('farm_profile', JSON.stringify(farmProfile)); }, [farmProfile]);

  const updateFarmProfile = (profile: FarmProfile) => {
    setFarmProfile(profile);
    addLog('System', 'Farm Business Profile updated.');
  };

  const addUser = (user: Omit<User, 'id'>) => {
    const newUser = { ...user, id: Date.now().toString(), password: hash(user.password || '1234') };
    setUsers([...users, newUser]);
  };

  const addTransaction = (t: Omit<Transaction, 'id'>) => {
    const newT = { ...t, id: Date.now().toString() };
    setTransactions(prev => [...prev, newT]);
  };

  const addDepartment = (name: string) => {
    const newDept = { id: Date.now().toString(), name };
    setDepartments([...departments, newDept]);
  };

  const addItem = (item: Omit<Item, 'id'>) => {
    const newItem = { ...item, id: Date.now().toString() };
    setItems([...items, newItem]);
    
    // Double Entry: Debit Inventory Asset, Credit Cash/Capital
    postToLedger([
      {
        date: new Date().toISOString(),
        description: `Purchase of Inventory: ${item.name}`,
        accountName: 'Inventory Asset',
        accountCategory: 'Asset',
        debit: item.costPrice * item.quantity,
        credit: 0,
        reference: newItem.id,
        userId: currentUser?.id || 'admin'
      },
      {
        date: new Date().toISOString(),
        description: `Payment for Inventory: ${item.name}`,
        accountName: 'Cash at Bank',
        accountCategory: 'Asset',
        debit: 0,
        credit: item.costPrice * item.quantity,
        reference: newItem.id,
        userId: currentUser?.id || 'admin'
      }
    ]);
  };

  const updateItemQuantity = (id: string, diff: number) => {
    setItems(prev => prev.map(item => 
      item.id === id ? { ...item, quantity: item.quantity + diff } : item
    ));
  };

  const addSale = (saleData: Omit<Sale, 'id'>) => {
    const newSale = { ...saleData, id: Date.now().toString() };
    setSales(prev => [...prev, newSale]);
    
    saleData.items.forEach(si => updateItemQuantity(si.itemId, -si.quantity));
    
    // Double Entry: Debit Cash, Credit Revenue
    postToLedger([
      {
        date: newSale.date,
        description: `Revenue from Sales: Invoice #${newSale.id.slice(-6)}`,
        accountName: 'Sales Revenue',
        accountCategory: 'Revenue',
        debit: 0,
        credit: newSale.total,
        reference: newSale.id,
        userId: currentUser?.id || 'admin'
      },
      {
        date: newSale.date,
        description: `Cash Receipt: Invoice #${newSale.id.slice(-6)}`,
        accountName: 'Cash at Bank',
        accountCategory: 'Asset',
        debit: newSale.total,
        credit: 0,
        reference: newSale.id,
        userId: currentUser?.id || 'admin'
      }
    ]);

    addLog('Sale', `System sale confirmed: $${newSale.total}`);
    return newSale;
  };

  const addAsset = (asset: Omit<Asset, 'id'>) => {
    const newAsset = { ...asset, id: Date.now().toString() };
    setAssets([...assets, newAsset]);
    
    // Double Entry: Debit PPE (Asset), Credit Cash
    postToLedger([
      {
        date: asset.purchaseDate,
        description: `Acquisition of Fixed Asset: ${asset.name}`,
        accountName: 'Property, Plant & Equipment',
        accountCategory: 'Asset',
        debit: asset.costValue,
        credit: 0,
        reference: newAsset.id,
        userId: currentUser?.id || 'admin'
      },
      {
        date: asset.purchaseDate,
        description: `Payment for Asset: ${asset.name}`,
        accountName: 'Cash at Bank',
        accountCategory: 'Asset',
        debit: 0,
        credit: asset.costValue,
        reference: newAsset.id,
        userId: currentUser?.id || 'admin'
      }
    ]);
    addLog('Accounting', `Manually registered new farm asset: ${asset.name}`);
  };

  const addExpense = (expense: Omit<Expense, 'id'>) => {
    const newExpense = { ...expense, id: Date.now().toString() };
    setExpenses([...expenses, newExpense]);
    
    // Double Entry: Debit Expense, Credit Cash
    postToLedger([
      {
        date: expense.date,
        description: `Operational Expense: ${expense.description}`,
        accountName: expense.category,
        accountCategory: 'Expense',
        debit: expense.amount,
        credit: 0,
        reference: newExpense.id,
        userId: currentUser?.id || 'admin'
      },
      {
        date: expense.date,
        description: `Payment for: ${expense.description}`,
        accountName: 'Cash at Bank',
        accountCategory: 'Asset',
        debit: 0,
        credit: expense.amount,
        reference: newExpense.id,
        userId: currentUser?.id || 'admin'
      }
    ]);
  };

  const addLog = (action: string, details: string) => {
    const newLog = {
      id: Date.now().toString(),
      action,
      user: userRole,
      timestamp: new Date().toISOString(),
      details
    };
    setAuditLogs(prev => [newLog, ...prev].slice(0, 100));
  };

  const [marketProducts, setMarketProducts] = useState<MarketProduct[]>(() => {
    const saved = localStorage.getItem('farm_market_products');
    return saved ? JSON.parse(saved) : [];
  });

  const [marketUsers, setMarketUsers] = useState<GlobalUser[]>(() => {
    const saved = localStorage.getItem('farm_market_users');
    return saved ? JSON.parse(saved) : [];
  });

  const [currentMarketUser, setCurrentMarketUser] = useState<GlobalUser | null>(() => {
    const saved = localStorage.getItem('farm_current_market_user');
    return saved ? JSON.parse(saved) : null;
  });

  useEffect(() => { localStorage.setItem('farm_market_products', JSON.stringify(marketProducts)); }, [marketProducts]);
  useEffect(() => { localStorage.setItem('farm_market_users', JSON.stringify(marketUsers)); }, [marketUsers]);
  
  const registerMarketUser = (data: Omit<GlobalUser, 'id'>) => {
    const newUser: GlobalUser = { ...data, id: 'MKT_' + Date.now(), password: hash(data.password || '1234') };
    const updated = [...marketUsers, newUser];
    setMarketUsers(updated);
    localStorage.setItem('farm_market_users', JSON.stringify(updated));
    return newUser;
  };

  const loginMarketUser = (email: string, pass: string) => {
    const hashed = hash(pass);
    // Find in the most up to date list
    const savedUsers = JSON.parse(localStorage.getItem('farm_market_users') || '[]');
    const user = savedUsers.find((u: GlobalUser) => u.email === email && u.password === hashed);
    
    if (user) {
      setCurrentMarketUser(user);
      localStorage.setItem('farm_current_market_user', JSON.stringify(user));
      return true;
    }
    return false;
  };

  const logoutMarketUser = () => {
    setCurrentMarketUser(null);
    localStorage.removeItem('farm_current_market_user');
  };

  const addMarketProduct = (prod: Omit<MarketProduct, 'id'>) => {
    const newProd = { ...prod, id: Date.now().toString() };
    const updated = [newProd, ...marketProducts];
    setMarketProducts(updated);
    localStorage.setItem('farm_market_products', JSON.stringify(updated));
    addLog('Market', `Listed ${prod.name} for sale.`);
  };

  const deleteMarketProduct = (id: string) => {
    const updated = marketProducts.filter(p => p.id !== id);
    setMarketProducts(updated);
    localStorage.setItem('farm_market_products', JSON.stringify(updated));
    addLog('Market', `Removed listing ID: ${id}`);
  };

  const deleteItem = (id: string) => setItems(items.filter(i => i.id !== id));
  const deleteSale = (id: string) => setSales(sales.filter(s => s.id !== id));
  const deleteExpense = (id: string) => setExpenses(expenses.filter(e => e.id !== id));

  return {
    marketProducts,
    marketUsers,
    currentMarketUser,
    registerMarketUser,
    loginMarketUser,
    logoutMarketUser,
    addMarketProduct,
    deleteMarketProduct,
    farmProfile,
    updateFarmProfile,
    ledger,
    auditLogs, addLog, currentUser, users, assets, transactions,
    addUser, updateUserPassword, addAsset, userRole, isAdmin, login, logout, registerFarm,
    departments, items, sales, expenses, addDepartment, addItem, addSale, 
    addExpense, deleteItem, deleteSale, deleteExpense
  };
};
