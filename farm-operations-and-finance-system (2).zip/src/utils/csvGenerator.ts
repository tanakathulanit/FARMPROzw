import { Sale, Expense, Item, Transaction } from '../types';

export const exportToCSV = (data: any[], fileName: string) => {
  if (data.length === 0) return;
  
  const headers = Object.keys(data[0]).join(',');
  const rows = data.map(row => 
    Object.values(row).map(val => 
      typeof val === 'string' ? `"${val.replace(/"/g, '""')}"` : val
    ).join(',')
  );
  
  const csvContent = [headers, ...rows].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `${fileName}.csv`);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

export const generateFinancialCSV = (sales: Sale[], expenses: Expense[], items: Item[], transactions: Transaction[], ledger: any[]) => {
  // World-Class Excel-Ready CSV Suite
  exportToCSV(ledger, 'FarmPro_ZW_General_Ledger');
  exportToCSV(transactions, 'FarmPro_ZW_Transaction_History');
  exportToCSV(items.map(i => ({ 
    'Product Name': i.name, 
    'Category': i.category,
    'Current Stock': i.quantity, 
    'Unit': i.unit,
    'Cost Price ($)': i.costPrice,
    'Selling Price ($)': i.sellingPrice,
    'Inventory Value ($)': i.quantity * i.costPrice 
  })), 'FarmPro_ZW_Inventory_Register');
  
  const totalSales = sales.reduce((a, c) => a + c.total, 0);
  const totalExp = expenses.reduce((a, c) => a + c.amount, 0);
  
  exportToCSV([
    { 'Financial Metric': 'Gross Sales Revenue', 'Amount ($)': totalSales },
    { 'Financial Metric': 'Total Operating Expenses', 'Amount ($)': totalExp },
    { 'Financial Metric': 'Net Trading Profit', 'Amount ($)': totalSales - totalExp }
  ], 'FarmPro_ZW_Trading_Profit_Loss');
};

export const exportWholeDatabaseExcel = (data: { items: any[], sales: any[], expenses: any[], assets: any[], ledger: any[] }) => {
  // Consolidated Enterprise Data Export
  exportToCSV(data.items, 'DB_Inventory');
  exportToCSV(data.sales, 'DB_Sales');
  exportToCSV(data.expenses, 'DB_Expenses');
  exportToCSV(data.assets, 'DB_Assets');
  exportToCSV(data.ledger, 'DB_General_Ledger');
};
