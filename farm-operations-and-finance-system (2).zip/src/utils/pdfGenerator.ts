import { jsPDF } from 'jspdf';
import 'jspdf-autotable';
import { Sale, FarmProfile } from '../types';
import { format } from 'date-fns';

export const generateReceipt = (sale: Sale, profile: FarmProfile) => {
  const doc = new jsPDF({
    unit: 'mm',
    format: [80, 150] 
  });

  // Business Header
  doc.setFontSize(10);
  doc.text(profile.name.toUpperCase(), 40, 10, { align: 'center' });
  doc.setFontSize(6);
  doc.text(profile.address, 40, 14, { align: 'center' });
  doc.text(`Contact: ${profile.contact} | ${profile.email}`, 40, 17, { align: 'center' });
  
  doc.line(5, 20, 75, 20);
  
  doc.setFontSize(8);
  doc.text('OFFICIAL SALE RECEIPT', 40, 25, { align: 'center' });
  
  doc.setFontSize(7);
  doc.text(`Staff: ${sale.userName}`, 5, 32);
  doc.text(`Date: ${format(new Date(sale.date), 'yyyy-MM-dd HH:mm')}`, 5, 36);
  doc.text(`ID: ${sale.id.slice(-8).toUpperCase()}`, 5, 40);
  
  doc.line(5, 42, 75, 42);
  
  doc.setFontSize(7);
  doc.text('ITEM', 5, 47);
  doc.text('QTY', 45, 47);
  doc.text('TOTAL', 65, 47);
  
  let y = 52;
  sale.items.forEach(item => {
    doc.text(item.itemName.substring(0, 22), 5, y);
    doc.text(item.quantity.toString(), 45, y);
    doc.text(`$${item.total.toFixed(2)}`, 65, y);
    y += 4;
  });
  
  doc.line(5, y + 2, 75, y + 2);
  doc.setFontSize(9);
  doc.text('GRAND TOTAL:', 40, y + 8, { align: 'right' });
  doc.text(`$${sale.total.toFixed(2)}`, 65, y + 8);
  
  doc.setFontSize(6);
  doc.text('Software by FarmPro ZW Enterprise', 40, y + 16, { align: 'center' });

  doc.save(`receipt_${sale.id}.pdf`);
};

export const generateReport = (title: string, data: any[], columns: string[]) => {
  const doc = new jsPDF();
  doc.text(title, 14, 15);
  doc.setFontSize(10);
  doc.text(`Generated on: ${format(new Date(), 'yyyy-MM-dd HH:mm')}`, 14, 22);
  
  (doc as any).autoTable({
    startY: 30,
    head: [columns],
    body: data,
    theme: 'striped',
    headStyles: { fillStyle: [16, 185, 129] }
  });

  doc.save(`${title.toLowerCase().replace(/\s/g, '_')}.pdf`);
};

export const printFinancialStatement = (title: string, content: any[], columns: string[]) => {
  const doc = new jsPDF();
  
  // High-End Header
  doc.setFillColor(16, 185, 129);
  doc.rect(0, 0, 210, 40, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(24);
  doc.text('FARMPRO ZW ENTERPRISE', 14, 20);
  doc.setFontSize(10);
  doc.text('Professional Financial Reporting Suite', 14, 30);
  
  doc.setTextColor(0, 0, 0);
  doc.setFontSize(18);
  doc.text(title.toUpperCase(), 14, 55);
  doc.setFontSize(10);
  doc.setTextColor(100, 100, 100);
  doc.text(`REPORTING DATE: ${format(new Date(), 'EEEE, MMMM do yyyy')}`, 14, 62);
  doc.text(`DEVELOPER: TANAKA T TIRIVANGANI`, 14, 67);

  (doc as any).autoTable({
    startY: 75,
    head: [columns],
    body: content,
    theme: 'grid',
    headStyles: { 
      fillColor: [30, 41, 59],
      textColor: [255, 255, 255],
      fontSize: 10,
      fontStyle: 'bold',
      halign: 'center'
    },
    styles: {
      fontSize: 9,
      cellPadding: 4
    },
    alternateRowStyles: {
      fillColor: [248, 250, 252]
    },
    margin: { top: 75 }
  });

  const finalY = (doc as any).lastAutoTable.finalY;
  doc.setFontSize(8);
  doc.setTextColor(150, 150, 150);
  doc.text('System Certified Financial Document - Proprietary Algorithm v4.0', 14, finalY + 20);
  doc.text('Authorized Signature: ___________________________', 130, finalY + 20);

  doc.save(`${title.toLowerCase().replace(/\s/g, '_')}.pdf`);
};

export const printWholeDatabase = (data: { items: any[], sales: any[], expenses: any[], assets: any[] }) => {
  const doc = new jsPDF();
  doc.setFillColor(16, 185, 129);
  doc.rect(0, 0, 210, 20, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(14);
  doc.text('FARMPRO ZW - COMPLETE ENTERPRISE DATABASE EXPORT', 105, 13, { align: 'center' });
  
  let currentY = 30;

  const addTable = (title: string, head: string[], body: any[]) => {
    if (currentY > 220) {
      doc.addPage();
      currentY = 20;
    }
    doc.setTextColor(0, 0, 0);
    doc.setFontSize(12);
    doc.text(title, 14, currentY);
    (doc as any).autoTable({
      startY: currentY + 5,
      head: [head],
      body: body,
      theme: 'grid',
      styles: { fontSize: 8 },
      margin: { left: 14, right: 14 }
    });
    currentY = (doc as any).lastAutoTable.finalY + 15;
  };

  addTable('INVENTORY REGISTER', ['Item', 'Category', 'Qty', 'Cost', 'Price'], data.items.map(i => [i.name, i.category, i.quantity, i.costPrice, i.sellingPrice]));
  addTable('SALES LOG', ['Date', 'ID', 'Total', 'User'], data.sales.map(s => [format(new Date(s.date), 'dd/MM'), s.id.slice(-6), s.total, s.userName]));
  addTable('EXPENSE LOG', ['Date', 'Desc', 'Cat', 'Amount'], data.expenses.map(e => [format(new Date(e.date), 'dd/MM'), e.description, e.category, e.amount]));
  addTable('ASSET REGISTER', ['Code', 'Asset', 'Cost', 'NBV'], data.assets.map(a => [a.code, a.name, a.costValue, (a.netBookValue || a.costValue)]));

  doc.save(`farmpro_database_export.pdf`);
};
