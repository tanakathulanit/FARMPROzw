export type UserRole = 'admin' | 'employee';

export interface User {
  id: string;
  name: string;
  role: UserRole;
  password?: string;
  subscriptionStatus: 'active' | 'expired' | 'trial';
  subscriptionTier: 'free' | 'pro' | 'enterprise';
  farmId: string;
  farmName: string;
  trialStartDate?: string;
  email?: string;
}

export interface FarmProfile {
  id: string;
  name: string;
  address: string;
  contact: string;
  email: string;
}

export type GlobalUserRole = 'buyer' | 'seller' | 'transporter' | 'farmer';

export interface GlobalUser {
  id: string;
  name: string;
  role: GlobalUserRole;
  phone: string;
  email: string;
  location?: string;
  password?: string;
  farmName?: string;
  farmId?: string;
  subscriptionStatus?: 'active' | 'expired' | 'trial';
  subscriptionTier?: 'free' | 'pro' | 'enterprise';
  services?: string[];
}

export interface MarketProduct {
  id: string;
  name: string;
  price: number;
  sellerId: string;
  sellerName: string;
  sellerPhone: string;
  farmId: string;
  category: string;
  description: string;
  date: string;
  location: {
    lat: number;
    lng: number;
    name: string;
  };
  imageUrl: string;
  type: 'product' | 'service';
}

export interface ServiceListing {
  id: string;
  providerId: string;
  providerName: string;
  providerPhone: string;
  type: 'transport' | 'labor' | 'equipment';
  description: string;
  priceRange: string;
  location: string;
}

export interface ServiceListing {
  id: string;
  providerId: string;
  providerName: string;
  providerPhone: string;
  type: 'transport' | 'labor' | 'equipment';
  description: string;
  priceRange: string;
  location: string;
}

export interface ProductLink {
  id: string;
  name: string;
  price: number;
  supplier: string;
  link: string;
}

export interface SaleItem {
  itemId: string;
  itemName: string;
  quantity: number;
  price: number;
  total: number;
}

export interface Sale {
  id: string;
  items: SaleItem[];
  total: number;
  date: string;
  departmentId: string;
  userId: string;
  userName: string;
}

export interface Asset {
  id: string;
  code: string;
  name: string;
  category: 'Land' | 'Buildings' | 'Machinery' | 'Livestock' | 'Vehicles';
  purchaseDate: string;
  costValue: number;
  depreciationRate: number;
  accumulatedDepreciation: number;
  netBookValue: number;
  status: 'active' | 'disposed' | 'written-off';
  departmentId: string;
}

export type AccountCategory = 'Revenue' | 'COGS' | 'Expense' | 'Asset' | 'Liability' | 'Equity';

export interface LedgerEntry {
  id: string;
  date: string;
  description: string;
  accountName: string;
  accountCategory: AccountCategory;
  debit: number;
  credit: number;
  reference: string;
  userId: string;
}

export interface Transaction {
  id: string;
  date: string;
  description: string;
  type: 'debit' | 'credit';
  account: string;
  amount: number;
  referenceId: string;
}

export interface Department {
  id: string;
  name: string;
}

export interface Item {
  id: string;
  name: string;
  category: string;
  quantity: number;
  unit: string;
  costPrice: number;
  sellingPrice: number;
  departmentId: string;
  imageUrl?: string;
  minStockLevel?: number;
  supplierName?: string;
}

export interface AuditLog {
  id: string;
  action: string;
  user: string;
  timestamp: string;
  details: string;
}

export interface Expense {
  id: string;
  description: string;
  amount: number;
  date: string;
  category: string;
  departmentId: string;
}
