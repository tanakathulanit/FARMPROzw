import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Link, useLocation, useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Package, 
  ShoppingCart, 
  Receipt, 
  Building2, 
  TrendingUp,
  ShieldCheck,
  Lock,
  LogOut,
  User,
  History,
  Printer,
  Calculator,
  Settings,
  UserPlus,
  FileText,
  LifeBuoy,
  Scale,
  Mail,
  MessageSquare,
  Zap,
  CreditCard,
  ShoppingBag,
  RefreshCw,
  Plus,
  Smartphone,
  Menu,
  X
} from 'lucide-react';
import { useFarmData } from './hooks/useFarmData';
import { format, startOfDay, endOfDay, isWithinInterval } from 'date-fns';
import { WifiOff, Wifi } from 'lucide-react';

import DashboardView from './components/DashboardView';
import InventoryView from './components/InventoryView';
import SalesView from './components/SalesView';
import ExpensesView from './components/ExpensesView';
import DepartmentsView from './components/DepartmentsView';
import AccountingView from './components/AccountingView';

import { generateReport, printWholeDatabase } from './utils/pdfGenerator';
import { generateFinancialCSV, exportWholeDatabaseExcel } from './utils/csvGenerator';
import { initiatePaynowPayment } from './utils/apiServices';
import { useOfflineSupport } from './hooks/useOfflineSupport';

// Website Components
import { Navbar, Footer, Home, FeaturePage, PricingPage } from './website/Components';
import { AboutPage, SecurityPage, FAQPage, POSAccounting, DeveloperProfile, ProductRoadmap, TermsPage, TechnicalHelpPage, PrivacyPolicyPage } from './website/Pages';
import { GlobalMarketplace } from './website/Market';

type View = 'dashboard' | 'inventory' | 'sales' | 'expenses' | 'departments' | 'admin-logs' | 'accounting' | 'settings' | 'support' | 'terms' | 'marketplace' | 'subscription' | 'pos-integration' | 'my-commodities';

const SystemApp = () => {
  const { isOnline } = useOfflineSupport();
  const navigate = useNavigate();
  const [activeView, setActiveView] = useState<View>('dashboard');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  const { 
    currentUser, users, isAdmin, login, logout, addUser, updateUserPassword, registerFarm,
    departments, items, sales, expenses, assets, transactions, auditLogs, addLog,
    marketProducts, addMarketProduct, marketUsers, currentMarketUser,
    registerMarketUser, loginMarketUser, logoutMarketUser,
    farmProfile, updateFarmProfile,
    addDepartment, addItem, addSale, addExpense, addAsset,
    deleteItem, deleteSale, deleteExpense, ledger
  } = useFarmData();

  const [isAddingItem, setIsAddingItem] = useState(false);
  const [isAddingSale, setIsAddingSale] = useState(false);
  const [isAddingExpense, setIsAddingExpense] = useState(false);
  const [isAddingDept, setIsAddingDept] = useState(false);
  const [passInput, setPassInput] = useState('');
  const [userIdInput, setUserIdInput] = useState('admin');
  const [showLoginError, setShowLoginError] = useState(false);

  const [isSubscribing, setIsSubscribing] = useState(false);

  const [posConfig, setPosConfig] = useState(() => {
    const saved = localStorage.getItem(`pos_config_${currentUser?.farmId}`);
    return saved ? JSON.parse(saved) : { id: '', key: '' };
  });

  const savePosConfig = (e: React.FormEvent) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget as HTMLFormElement);
    const config = { id: formData.get('id'), key: formData.get('key') };
    setPosConfig(config);
    localStorage.setItem(`pos_config_${currentUser?.farmId}`, JSON.stringify(config));
    alert("POS Merchant Credentials Saved Successfully.");
  };

  const handleSubscription = async (amount: number) => {
    setIsSubscribing(amount === 0 ? false : true);
    if (amount === 0) return;
    try {
      const payment = await initiatePaynowPayment(amount, currentUser?.id || 'admin', 'SUB-RENEW') as any;
      if (payment.success) {
        alert('Subscription Payment Initiated. Your system access will be automatically maintained upon PIN confirmation.');
        
        // FOR SIMULATION: In real app, the Paynow Webhook would do this. 
        // Here we simulate the successful payment to show you how the access is granted.
        if (currentUser) {
          currentUser.subscriptionStatus = 'active';
          currentUser.subscriptionTier = amount > 50 ? 'enterprise' : 'pro';
          localStorage.setItem('farm_current_user', JSON.stringify(currentUser));
          // Update the users list too
          const updatedUsers = users.map(u => u.id === currentUser.id ? currentUser : u);
          localStorage.setItem('farm_users', JSON.stringify(updatedUsers));
        }
        
        addLog('Billing', `Initiated subscription payment for $${amount}`);
      }
    } catch (err) {
      alert('Subscription failed to initiate.');
    }
    setIsSubscribing(false);
  };

  const handleAccess = (e: React.FormEvent) => {
    e.preventDefault();
    const success = login(userIdInput, passInput);
    if (success) {
      addLog('System Access', `${userIdInput} logged into system`);
      setIsLoggedIn(true);
      setPassInput('');
      setShowLoginError(false);
    } else {
      setShowLoginError(true);
    }
  };

  const handleLogout = () => {
    addLog('System Exit', 'User logged out');
    logout();
    setIsLoggedIn(false);
  };

  // Security: Auto-logout after 20 mins of inactivity
  useEffect(() => {
    if (!isLoggedIn) return;
    
    let timer: any;
    const resetTimer = () => {
      clearTimeout(timer);
      timer = setTimeout(() => {
        handleLogout();
        alert('Session expired for your security. Please log in again.');
      }, 20 * 60 * 1000); // 20 mins
    };

    window.onmousemove = resetTimer;
    window.onkeydown = resetTimer;
    resetTimer();

    return () => {
      window.onmousemove = null;
      window.onkeydown = null;
      clearTimeout(timer);
    };
  }, [isLoggedIn]);

  useEffect(() => {
    const savedRole = localStorage.getItem('farm_user_role');
    if (savedRole) setIsLoggedIn(true);
  }, []);

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-emerald-950 flex flex-col items-center justify-center p-4">
        <Link to="/" className="mb-8 flex items-center gap-2">
           <Building2 size={32} className="text-emerald-500" />
           <span className="text-2xl font-black text-white tracking-tighter">FarmPro <span className="text-emerald-500">ZW</span></span>
        </Link>
        <div className="max-w-md w-full bg-white rounded-3xl shadow-2xl overflow-hidden border border-emerald-900/20">
          <div className="p-8 bg-emerald-800 text-white text-center">
            <h1 className="text-2xl font-black tracking-tight uppercase">Portal Login</h1>
            <p className="text-emerald-200 mt-1 font-medium opacity-80 uppercase text-[10px] tracking-widest">Enterprise Access Only</p>
          </div>
          <form onSubmit={handleAccess} className="p-8 space-y-4">
            <div className="space-y-2">
              <label className="text-xs font-black text-slate-500 uppercase tracking-wider px-1">Select User Profile</label>
              <select 
                className="w-full px-4 py-3 rounded-xl border-2 border-slate-100 outline-none focus:border-emerald-500 transition-all font-bold text-slate-700 bg-slate-50"
                value={userIdInput}
                onChange={(e) => setUserIdInput(e.target.value)}
              >
                {users.map(u => (
                  <option key={u.id} value={u.id}>{u.name} ({u.role})</option>
                ))}
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-xs font-black text-slate-500 uppercase tracking-wider px-1">Access Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input 
                  type="password"
                  placeholder="Password"
                  className="w-full pl-10 pr-4 py-3 rounded-xl border-2 border-slate-100 outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all font-medium"
                  value={passInput}
                  onChange={(e) => {
                    setPassInput(e.target.value);
                    setShowLoginError(false);
                  }}
                />
              </div>
              {showLoginError && <p className="text-xs text-rose-500 font-bold px-1 animate-pulse">Authentication failed. Contact Admin.</p>}
            </div>
            <button className="w-full py-4 mt-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-black text-lg shadow-lg transition-all active:scale-95">
              ENTER SYSTEM
            </button>
            <Link to="/support" className="block text-center py-2 text-xs font-bold text-slate-400 hover:text-emerald-600 transition-colors">
              Request Access / Forgot Password?
            </Link>
          </form>
        </div>
        <Link to="/" className="mt-8 text-emerald-400 text-sm font-bold hover:underline italic tracking-widest uppercase">← Return to Main Website</Link>
      </div>
    );
  }

  // Profit & Loss Calculations
  const totalSales = sales.reduce((acc, curr) => acc + curr.total, 0);
  const totalExpenses = expenses.reduce((acc, curr) => acc + curr.amount, 0);
  const profitLoss = totalSales - totalExpenses;

  const today = new Date();
  const todaysSales = sales.filter(s => 
    isWithinInterval(new Date(s.date), {
      start: startOfDay(today),
      end: endOfDay(today)
    })
  ).reduce((acc, curr) => acc + curr.total, 0);

  const sidebarItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'inventory', label: 'Inventory', icon: Package },
    { id: 'sales', label: 'Sales', icon: ShoppingCart },
    { id: 'expenses', label: 'Expenses', icon: Receipt },
    { id: 'departments', label: 'Departments', icon: Building2 },
    { id: 'marketplace', label: 'Marketplace', icon: ShoppingBag },
    { id: 'my-commodities', label: 'My Produce', icon: Zap },
    ...(isAdmin ? [
      { id: 'pos-integration', label: 'POS Config', icon: Smartphone },
      { id: 'accounting', label: 'Financials', icon: Calculator },
      { id: 'admin-logs', label: 'Audit Logs', icon: History },
      { id: 'settings', label: 'Settings', icon: Settings },
      { id: 'subscription', label: 'Billing', icon: CreditCard }
    ] : []),
    { id: 'support', label: 'Support', icon: LifeBuoy },
    { id: 'terms', label: 'Legal', icon: Scale },
  ];

  return (
    <div className="flex h-screen bg-gray-50 text-slate-900 font-sans relative overflow-hidden">
      {/* Mobile Menu Overlay */}
      {isMobileSidebarOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[140] lg:hidden"
          onClick={() => setIsMobileSidebarOpen(false)}
        ></div>
      )}

      {/* Sidebar */}
      <aside className={`fixed lg:static inset-y-0 left-0 w-64 bg-emerald-800 text-white flex flex-col shrink-0 z-[150] transition-transform duration-300 lg:translate-x-0 ${isMobileSidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="p-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-emerald-50 p-2 rounded-lg">
              <Building2 size={24} />
            </div>
            <span className="text-xl font-bold tracking-tight">FarmPro ZW</span>
          </div>
          <button onClick={() => setIsMobileSidebarOpen(false)} className="lg:hidden p-2 hover:bg-emerald-700 rounded-lg">
            <X size={20} />
          </button>
        </div>

        <div className="px-6 mb-4">
          <div className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider ${
            isAdmin ? 'bg-amber-400 text-amber-950' : 'bg-emerald-700 text-emerald-100'
          }`}>
            {isAdmin ? <ShieldCheck size={14} /> : <User size={14} />}
            {isAdmin ? 'Admin' : 'Employee'} Mode
          </div>
        </div>
        
        <nav className="flex-1 px-4 py-4 space-y-1 overflow-y-auto">
          {sidebarItems.map((item) => {
            const isExternal = ['marketplace', 'support', 'terms'].includes(item.id);
            return (
              <button
                key={item.id}
                onClick={() => {
                  if (item.id === 'marketplace') navigate('/marketplace');
                  else if (item.id === 'support') navigate('/support');
                  else if (item.id === 'terms') navigate('/terms');
                  else {
                    setActiveView(item.id as View);
                    setIsMobileSidebarOpen(false);
                  }
                }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                  !isExternal && activeView === item.id 
                  ? 'bg-emerald-700 shadow-lg text-white' 
                  : 'text-emerald-100 hover:bg-emerald-700/50'
                }`}
              >
                <item.icon size={20} />
                <span className="font-medium">{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-emerald-700/50 space-y-3">
          <button 
            onClick={handleLogout}
            className="w-full py-3 bg-emerald-900/50 hover:bg-rose-900/40 text-emerald-100 hover:text-rose-100 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 border border-emerald-700/50"
          >
            <LogOut size={14} />
            EXIT SYSTEM
          </button>

          <div className="bg-emerald-900/50 p-4 rounded-xl">
            <div className="flex items-center gap-2 text-sm text-emerald-300 mb-1">
              <TrendingUp size={14} />
              Today's Sales
            </div>
            <div className="text-lg font-bold">${todaysSales.toLocaleString()}</div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto bg-slate-50 flex flex-col h-full">
        <header className="bg-white border-b border-slate-200 px-4 lg:px-8 py-4 lg:py-6 sticky top-0 z-[130]">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-4">
              <button 
                onClick={() => setIsMobileSidebarOpen(true)}
                className="lg:hidden p-2 text-slate-600 hover:bg-slate-100 rounded-xl"
              >
                <Menu size={24} />
              </button>
              <h1 className="text-lg lg:text-2xl font-bold text-slate-800 capitalize flex items-center gap-3">
                {activeView === 'admin-logs' && <History className="text-emerald-600" size={24} />}
                {activeView.replace('-', ' ')}
              </h1>
            </div>
            <div className="flex items-center gap-2 lg:gap-4">
              <div className={`hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest ${isOnline ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>
                {isOnline ? <Wifi size={12}/> : <WifiOff size={12}/>}
                {isOnline ? 'Sync Active' : 'Offline'}
              </div>
              {isAdmin && activeView === 'inventory' && (
                <button 
                  onClick={() => generateReport('Inventory Database', items.map(i => [i.name, i.category, i.quantity, i.unit, i.costPrice, i.sellingPrice]), ['Name', 'Category', 'Stock', 'Unit', 'Cost', 'Price'])}
                  className="hidden md:flex items-center gap-2 bg-slate-100 hover:bg-slate-200 px-4 py-2 rounded-xl text-sm font-bold text-slate-700 transition-all"
                >
                  <Printer size={16} /> Print
                </button>
              )}
              {isAdmin && (
                <button 
                  onClick={() => exportWholeDatabaseExcel({ items, sales, expenses, assets, ledger })}
                  className="flex items-center gap-2 bg-emerald-600 text-white px-3 py-1.5 lg:px-4 lg:py-2 rounded-lg text-[10px] lg:text-xs font-black hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-900/20"
                >
                  <FileText size={14} /> <span className="hidden sm:inline">EXCEL DB</span>
                </button>
              )}
              <span className="hidden lg:inline text-sm font-medium text-slate-500 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-100">
                {format(new Date(), 'EEEE, MMMM do yyyy')}
              </span>
            </div>
          </div>
        </header>

        <div className="p-8">
          {activeView === 'accounting' && isAdmin && (
            currentUser?.subscriptionTier === 'free' ? (
              <div className="flex flex-col items-center justify-center py-20 text-center space-y-6">
                <div className="w-24 h-24 bg-amber-100 text-amber-600 rounded-full flex items-center justify-center">
                  <Lock size={48} />
                </div>
                <div className="max-w-md">
                  <h2 className="text-3xl font-black text-slate-800 mb-2">Pro Feature Locked</h2>
                  <p className="text-slate-500 font-medium">Detailed Accounting, Balance Sheets, and Financial Exports are only available on the Professional Plan.</p>
                </div>
                <button 
                  onClick={() => setActiveView('subscription')}
                  className="bg-emerald-600 text-white px-8 py-3 rounded-2xl font-black shadow-lg hover:bg-emerald-700 transition-all"
                >
                  UPGRADE TO PRO ($45/mo)
                </button>
              </div>
            ) : (
              <AccountingView 
                ledger={ledger} 
                assets={assets}
                sales={sales}
                expenses={expenses}
                items={items}
                farmProfile={farmProfile}
                addAsset={addAsset}
              />
            )
          )}

          {activeView === 'settings' && isAdmin && (
            <div className="space-y-8 max-w-2xl">
              {/* Farm Business Profile */}
              <div className="bg-white p-8 rounded-[40px] border border-slate-100 shadow-sm space-y-6">
                <h3 className="text-xl font-black text-slate-800 flex items-center gap-3">
                  <Building2 className="text-emerald-600" /> Farm Business Profile
                </h3>
                <p className="text-slate-400 text-xs font-bold uppercase tracking-widest leading-none">Settings for Receipt Headers & Statements</p>
                
                <form 
                  onSubmit={(e) => {
                    e.preventDefault();
                    const formData = new FormData(e.currentTarget);
                    updateFarmProfile({
                      id: farmProfile.id,
                      name: formData.get('name') as string,
                      address: formData.get('address') as string,
                      contact: formData.get('contact') as string,
                      email: formData.get('email') as string
                    });
                    alert("Business Profile Updated Successfully.");
                  }}
                  className="space-y-4 pt-4"
                >
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black text-slate-400 uppercase ml-2">Business Name</label>
                    <input name="name" defaultValue={farmProfile.name} required className="w-full p-4 rounded-2xl border-2 border-slate-50 outline-none focus:border-emerald-500 font-bold bg-slate-50" />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black text-slate-400 uppercase ml-2">Physical Address</label>
                    <input name="address" defaultValue={farmProfile.address} required className="w-full p-4 rounded-2xl border-2 border-slate-50 outline-none focus:border-emerald-500 font-bold bg-slate-50" />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-black text-slate-400 uppercase ml-2">Contact Phone</label>
                      <input name="contact" defaultValue={farmProfile.contact} required className="w-full p-4 rounded-2xl border-2 border-slate-50 outline-none focus:border-emerald-500 font-bold bg-slate-50" />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-black text-slate-400 uppercase ml-2">Business Email</label>
                      <input name="email" type="email" defaultValue={farmProfile.email} required className="w-full p-4 rounded-2xl border-2 border-slate-50 outline-none focus:border-emerald-500 font-bold bg-slate-50" />
                    </div>
                  </div>
                  <button className="w-full py-5 bg-slate-900 text-white rounded-3xl font-black uppercase shadow-xl hover:bg-emerald-600 transition-all tracking-tighter">
                    Save Business Identity
                  </button>
                </form>
              </div>

              <div className="bg-white p-8 rounded-[40px] border border-slate-100 shadow-sm space-y-6">
                <h3 className="text-xl font-black text-slate-800 flex items-center gap-3">
                  <UserPlus className="text-emerald-600" /> Staff Accounts
                </h3>
                <div className="space-y-4">
                  {users.map(u => (
                    <div key={u.id} className="flex justify-between items-center p-6 bg-slate-50 rounded-[32px] border border-slate-100">
                      <div>
                        <div className="font-black text-slate-800">{u.name}</div>
                        <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">ID: {u.id} • {u.role}</div>
                      </div>
                      <button 
                        onClick={() => {
                          const newPass = prompt('Enter new password for ' + u.name);
                          if (newPass) updateUserPassword(u.id, newPass);
                        }}
                        className="text-[10px] font-black uppercase bg-white px-4 py-2 rounded-xl border border-slate-200 shadow-sm hover:text-emerald-600 transition-all"
                      >
                        Reset Password
                      </button>
                    </div>
                  ))}
                  <button 
                    onClick={() => {
                      const name = prompt('Employee Name');
                      const pass = prompt('Set Password');
                      if (name && pass) {
                        addUser({
                          name,
                          role: 'employee',
                          password: pass,
                          subscriptionStatus: 'active',
                          subscriptionTier: 'free',
                          farmId: currentUser?.farmId || '',
                          farmName: currentUser?.farmName || '',
                          email: ''
                        });
                      }
                    }}
                    className="w-full py-5 border-4 border-dashed border-slate-100 text-slate-300 rounded-[40px] font-black uppercase text-xs hover:border-emerald-200 hover:text-emerald-300 transition-all"
                  >
                    + Provision New Employee Account
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeView === 'admin-logs' && isAdmin && (
            <div className="space-y-6">
               <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50/50 border-b border-slate-200">
                      <th className="px-6 py-4 text-xs font-black text-slate-500 uppercase">Timestamp</th>
                      <th className="px-6 py-4 text-xs font-black text-slate-500 uppercase">Action</th>
                      <th className="px-6 py-4 text-xs font-black text-slate-500 uppercase">User</th>
                      <th className="px-6 py-4 text-xs font-black text-slate-500 uppercase">Details</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {auditLogs.map((log: any) => (
                      <tr key={log.id} className="hover:bg-slate-50/50 transition-colors">
                        <td className="px-6 py-4 text-xs text-slate-500 font-medium">
                          {format(new Date(log.timestamp), 'MMM dd, HH:mm:ss')}
                        </td>
                        <td className="px-6 py-4">
                          <span className="px-2 py-1 bg-emerald-50 text-emerald-700 rounded-md text-[10px] font-black uppercase">
                            {log.action}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-xs font-bold text-slate-700 uppercase">{log.user}</td>
                        <td className="px-6 py-4 text-xs text-slate-600 font-medium">{log.details}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
          {activeView === 'dashboard' && (
            <DashboardView 
              sales={sales} 
              expenses={expenses} 
              totalSales={totalSales} 
              totalExpenses={totalExpenses} 
              profitLoss={profitLoss}
            />
          )}
          {activeView === 'inventory' && (
            <InventoryView 
              items={items} 
              departments={departments} 
              addItem={addItem} 
              deleteItem={deleteItem}
              isAdding={isAddingItem}
              setIsAdding={setIsAddingItem}
              isAdmin={isAdmin}
            />
          )}
          {activeView === 'sales' && (
            <SalesView 
              sales={sales} 
              items={items} 
              departments={departments} 
              currentUser={currentUser}
              farmProfile={farmProfile}
              addSale={addSale} 
              deleteSale={deleteSale}
              isAdding={isAddingSale}
              setIsAdding={setIsAddingSale}
              isAdmin={isAdmin}
            />
          )}
          {activeView === 'expenses' && (
            <ExpensesView 
              expenses={expenses} 
              departments={departments} 
              addExpense={addExpense} 
              deleteExpense={deleteExpense}
              isAdding={isAddingExpense}
              setIsAdding={setIsAddingExpense}
              isAdmin={isAdmin}
            />
          )}
          {activeView === 'departments' && (
            <DepartmentsView 
              departments={departments} 
              items={items}
              sales={sales}
              expenses={expenses}
              addDepartment={addDepartment}
              isAdding={isAddingDept}
              setIsAdding={setIsAddingDept}
            />
          )}

          {activeView === 'support' && (
            <div className="max-w-4xl mx-auto py-12 px-6">
              <div className="bg-white rounded-3xl shadow-xl overflow-hidden border border-slate-100">
                <div className="bg-emerald-800 p-12 text-white text-center">
                  <LifeBuoy size={64} className="mx-auto mb-6 opacity-80" />
                  <h2 className="text-4xl font-black mb-4">How can we help?</h2>
                  <p className="text-emerald-100 text-lg max-w-2xl mx-auto">
                    Get in touch with the FarmPro ZW technical team for assistance with your management system.
                  </p>
                </div>
                <div className="p-12 grid grid-cols-1 md:grid-cols-2 gap-8">
                  <a href="mailto:thulanitanaka144@gmail.com?subject=FarmPro%20ZW%20Support%20Request&body=Hello%20Tanaka,%20I%20am%20using%20the%20FarmPro%20ZW%20system%20and%20I%20need%20assistance%20with..." className="group p-8 rounded-3xl bg-slate-50 border-2 border-slate-100 hover:border-emerald-500 hover:bg-emerald-50 transition-all text-center">
                    <div className="w-16 h-16 bg-white rounded-2xl shadow-sm flex items-center justify-center mx-auto mb-6 text-emerald-600 group-hover:scale-110 transition-transform border border-slate-100">
                      <Mail size={32} />
                    </div>
                    <h3 className="text-xl font-black text-slate-800 mb-2">Email Support</h3>
                    <div className="bg-white px-4 py-2 rounded-xl border border-slate-200 inline-block mb-4">
                      <p className="text-emerald-700 font-black text-sm">thulanitanaka144@gmail.com</p>
                    </div>
                    <div className="text-xs font-black text-emerald-600 uppercase tracking-widest block">Send Auto-Message</div>
                  </a>
                  <a href="https://wa.me/263713022994?text=Hello%20FarmPro%20ZW%20Support,%20I%20am%20a%20registered%20user%20and%20I%20require%20technical%20assistance." target="_blank" rel="noopener noreferrer" className="group p-8 rounded-3xl bg-slate-50 border-2 border-slate-100 hover:border-emerald-500 hover:bg-emerald-50 transition-all text-center">
                    <div className="w-16 h-16 bg-white rounded-2xl shadow-sm flex items-center justify-center mx-auto mb-6 text-emerald-600 group-hover:scale-110 transition-transform border border-slate-100">
                      <MessageSquare size={32} />
                    </div>
                    <h3 className="text-xl font-black text-slate-800 mb-2">WhatsApp Support</h3>
                    <div className="bg-white px-4 py-2 rounded-xl border border-slate-200 inline-block mb-4">
                      <p className="text-emerald-700 font-black text-sm">+263 71 302 2994</p>
                    </div>
                    <div className="text-xs font-black text-emerald-600 uppercase tracking-widest block">Chat Now</div>
                  </a>
                </div>
                <div className="p-8 bg-slate-50 border-t border-slate-100 text-center">
                  <p className="text-slate-400 text-xs font-bold uppercase tracking-widest">
                    System Developed & Maintained by <span className="text-emerald-600">Tanaka T Tirivangani</span>
                  </p>
                </div>
              </div>
            </div>
          )}

          {activeView === 'terms' && (
            <div className="max-w-4xl mx-auto py-12 px-6">
              <div className="bg-white p-12 rounded-3xl shadow-xl border border-slate-100 space-y-8">
                <div className="flex items-center gap-4 mb-8">
                  <div className="bg-emerald-100 p-4 rounded-2xl text-emerald-600">
                    <Scale size={32} />
                  </div>
                  <h2 className="text-3xl font-black text-slate-800">Terms & Conditions</h2>
                </div>
                <div className="space-y-6 text-slate-600 leading-relaxed">
                  <section>
                    <h3 className="text-xl font-bold text-slate-800 mb-2">1. System Use</h3>
                    <p>FarmPro ZW Enterprise is designed for internal agricultural management. Users are responsible for maintaining the confidentiality of their access credentials.</p>
                  </section>
                  <section>
                    <h3 className="text-xl font-bold text-slate-800 mb-2">2. Data Privacy</h3>
                    <p>All data entered into this system is stored locally within the browser's storage. It is the administrator's responsibility to perform periodic backups using the Export functionality.</p>
                  </section>
                  <section>
                    <h3 className="text-xl font-bold text-slate-800 mb-2">3. Accountability</h3>
                    <p>Every transaction and modification is logged with a timestamp and user ID. The system owner is responsible for all activities conducted under their administrative account.</p>
                  </section>
                  <section>
                    <h3 className="text-xl font-bold text-slate-800 mb-2">4. Technical Support</h3>
                    <p>For technical issues, contact the developer, Tanaka T Tirivangani, through the official support channels provided in the Support section.</p>
                  </section>
                </div>
                <div className="pt-12 border-t border-slate-100 text-slate-400 text-sm italic">
                  Last updated: March 2026
                </div>
              </div>
            </div>
          )}

          {activeView === 'marketplace' && (
            <div className="space-y-8 h-full overflow-y-auto">
               <GlobalMarketplace products={marketProducts} currentUser={currentUser} isERP={true} />
            </div>
          )}

          {activeView === 'my-commodities' && (
            <div className="space-y-8">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-black text-slate-800">My Sales Portal</h2>
                <button 
                  onClick={() => setIsAddingItem(true)}
                  className="bg-emerald-600 text-white px-6 py-3 rounded-xl font-black flex items-center gap-2"
                >
                  <Plus size={18} /> List New Commodity
                </button>
              </div>

              {/* My Listings Table */}
              <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden">
                <table className="w-full text-left">
                  <thead className="bg-slate-50 border-b border-slate-200">
                    <tr>
                      <th className="p-6 text-xs font-black uppercase text-slate-400">Product</th>
                      <th className="p-6 text-xs font-black uppercase text-slate-400">Category</th>
                      <th className="p-6 text-xs font-black uppercase text-slate-400">Price</th>
                      <th className="p-6 text-xs font-black uppercase text-slate-400">Date Listed</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {marketProducts.filter((p: any) => p.farmId === currentUser?.farmId).map((p: any) => (
                      <tr key={p.id}>
                        <td className="p-6 font-bold text-slate-800">{p.name}</td>
                        <td className="p-6 text-sm text-slate-500">{p.category}</td>
                        <td className="p-6 font-black text-emerald-600">${p.price}</td>
                        <td className="p-6 text-sm text-slate-400">{format(new Date(p.date), 'MMM dd, yyyy')}</td>
                      </tr>
                    ))}
                    {marketProducts.filter((p: any) => p.farmId === currentUser?.farmId).length === 0 && (
                      <tr><td colSpan={4} className="p-12 text-center text-slate-400 italic">You have no active listings.</td></tr>
                    )}
                  </tbody>
                </table>
              </div>

              {/* Add Listing Overlay */}
              {isAddingItem && (
                <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
                  <div className="bg-white rounded-[40px] shadow-2xl w-full max-w-lg overflow-hidden animate-in zoom-in duration-200">
                    <div className="p-10 border-b border-slate-100">
                      <h3 className="text-2xl font-black text-slate-800">Post to Marketplace</h3>
                      <p className="text-slate-500 text-sm mt-1 font-medium italic">Your product will be visible to all farms in Zimbabwe.</p>
                    </div>
                    <form 
                      onSubmit={(e) => {
                        e.preventDefault();
                        const formData = new FormData(e.currentTarget);
                addMarketProduct({
                  name: formData.get('name') as string,
                  price: Number(formData.get('price')),
                  category: formData.get('category') as string,
                  description: formData.get('desc') as string,
                  sellerId: currentUser?.id || '',
                  sellerName: currentUser?.name || '',
                  sellerPhone: prompt("Confirm your WhatsApp Number (e.g. 263771234567)") || '',
                  farmId: currentUser?.farmId || '',
                  date: new Date().toISOString(),
                  location: { lat: -17.82, lng: 31.05, name: 'Harare, ZW' }, // Default for ERP
                  imageUrl: 'https://images.unsplash.com/photo-1523348837708-15d4a09cfac2?auto=format&fit=crop&w=800&q=80',
                  type: 'product'
                });
                        setIsAddingItem(false);
                      }}
                      className="p-10 space-y-4"
                    >
                      <input name="name" placeholder="Commodity Name (e.g. Yellow Maize)" required className="w-full p-4 rounded-2xl border-2 border-slate-100 outline-none focus:border-emerald-500 font-bold" />
                      <div className="grid grid-cols-2 gap-4">
                        <input name="price" type="number" step="0.01" placeholder="Price (USD)" required className="w-full p-4 rounded-2xl border-2 border-slate-100 outline-none focus:border-emerald-500 font-bold" />
                        <select name="category" className="w-full p-4 rounded-2xl border-2 border-slate-100 outline-none focus:border-emerald-500 font-bold">
                          <option>Grains</option>
                          <option>Livestock</option>
                          <option>Vegetables</option>
                          <option>Poultry</option>
                        </select>
                      </div>
                      <textarea name="desc" placeholder="Brief description of quality and location..." required className="w-full p-4 h-32 rounded-2xl border-2 border-slate-100 outline-none focus:border-emerald-500 font-bold" />
                      <div className="flex gap-4 pt-4">
                        <button type="button" onClick={() => setIsAddingItem(false)} className="flex-1 py-4 bg-slate-100 text-slate-500 rounded-2xl font-black">Cancel</button>
                        <button type="submit" className="flex-[2] py-4 bg-emerald-600 text-white rounded-2xl font-black shadow-lg shadow-emerald-900/20">List Now</button>
                      </div>
                    </form>
                  </div>
                </div>
              )}
            </div>
          )}

          {activeView === 'pos-integration' && isAdmin && (
            <div className="max-w-3xl space-y-8">
              <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
                <h2 className="text-2xl font-black text-slate-800 mb-6 flex items-center gap-3">
                  <Smartphone className="text-emerald-600" /> POS Payment Integration
                </h2>
                <p className="text-slate-500 mb-8 font-medium">Configure your farm's merchant credentials to receive electronic payments at the point of sale.</p>
                
                <form onSubmit={savePosConfig} className="space-y-6">
                  <div className="grid grid-cols-1 gap-6">
                    <div className="space-y-2">
                      <label className="text-xs font-black text-slate-400 uppercase">Paynow Integration ID</label>
                      <input name="id" defaultValue={posConfig.id} type="text" placeholder="e.g. 12345" className="w-full px-4 py-3 rounded-xl border-2 border-slate-100 focus:border-emerald-500 outline-none font-bold" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-black text-slate-400 uppercase">Integration Secret Key</label>
                      <input name="key" defaultValue={posConfig.key} type="password" placeholder="••••••••••••••••" className="w-full px-4 py-3 rounded-xl border-2 border-slate-100 focus:border-emerald-500 outline-none font-bold" />
                    </div>
                  </div>
                  <div className="p-4 bg-emerald-50 rounded-2xl flex items-start gap-4">
                    <ShieldCheck className="text-emerald-600 shrink-0" size={20} />
                    <p className="text-xs text-emerald-800 font-medium">By connecting your Paynow credentials, customers can pay via EcoCash and InnBucks. All funds go directly to your mobile wallet.</p>
                  </div>
                  <button className="w-full py-4 bg-slate-900 text-white rounded-xl font-black shadow-lg">SAVE INTEGRATION</button>
                </form>
              </div>
            </div>
          )}

          {activeView === 'my-commodities' && (
            <div className="space-y-8">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-black text-slate-800">My Sale Commodities</h2>
                <button 
                  onClick={() => setIsAddingItem(true)}
                  className="bg-emerald-600 text-white px-6 py-3 rounded-xl font-black flex items-center gap-2"
                >
                  <Plus size={18} /> Register Produce for Sale
                </button>
              </div>
              <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden">
                <div className="p-12 text-center space-y-4">
                  <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto text-slate-400">
                    <Package size={40} />
                  </div>
                  <h3 className="text-xl font-bold text-slate-800">No Sale Commodities Yet</h3>
                  <p className="text-slate-500 max-w-sm mx-auto">Use the button above to manually register the produce you want to list on the marketplace or sell via POS.</p>
                </div>
              </div>
            </div>
          )}

          {activeView === 'subscription' && (
            <div className="max-w-5xl mx-auto space-y-12">
              <div className="text-center space-y-4">
                <h2 className="text-5xl font-black text-slate-800 tracking-tight">Upgrade Your Farm</h2>
                <p className="text-slate-500 text-lg">Choose a plan that scales with your agricultural empire.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {[
                  { name: 'Starter', price: 0, features: ['1 Department', 'Basic POS', 'Local Backup'], pro: false },
                  { name: 'Professional', price: 45, features: ['Unlimited Departments', 'Cloud Sync', 'Advanced Accounting', 'CSV Exports', 'Priority Email Support'], pro: true },
                  { name: 'Enterprise', price: 150, features: ['Multi-Farm Support', 'Hardware POS Bundle', 'Personal Account Manager', 'Custom API Access', 'Training Workshop'], pro: false }
                ].map((plan, idx) => (
                  <div key={idx} className={`relative p-10 rounded-[40px] border-2 transition-all ${plan.pro ? 'border-emerald-500 bg-white shadow-2xl scale-105 z-10' : 'border-slate-100 bg-white shadow-sm'}`}>
                    {plan.pro && (
                      <div className="absolute -top-5 left-1/2 -translate-x-1/2 bg-emerald-500 text-white px-6 py-1.5 rounded-full text-xs font-black uppercase tracking-widest">
                        Most Popular
                      </div>
                    )}
                    <div className="text-sm font-black text-slate-400 uppercase tracking-[0.2em] mb-4">{plan.name}</div>
                    <div className="flex items-baseline gap-1 mb-8">
                      <span className="text-5xl font-black text-slate-800">${plan.price}</span>
                      <span className="text-slate-400 font-bold">/month</span>
                    </div>
                    <ul className="space-y-4 mb-10">
                      {plan.features.map((f, i) => (
                        <li key={i} className="flex items-center gap-3 text-sm font-medium text-slate-600">
                          <Zap size={14} className="text-emerald-500" /> {f}
                        </li>
                      ))}
                    </ul>
                    <button 
                      onClick={() => {
                        if (plan.price === 0) {
                          alert("Please contact the Administrator via the Support page to activate your Free Trial.");
                        } else {
                          handleSubscription(plan.price);
                        }
                      }}
                      disabled={isSubscribing}
                      className={`w-full py-4 rounded-2xl font-black text-lg transition-all flex items-center justify-center gap-2 ${plan.pro ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-900/20 hover:bg-emerald-700' : 'bg-slate-100 text-slate-800 hover:bg-slate-200'}`}
                    >
                      {isSubscribing && plan.price > 0 ? <RefreshCw className="animate-spin" size={20} /> : (plan.price === 0 ? 'Join Now' : 'Buy ' + plan.name)}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

const MainSiteLayout = ({ children }: { children: React.ReactNode }) => (
  <div className="flex flex-col min-h-screen">
    <Navbar />
    <main className="flex-grow">
      {children}
    </main>
    <Footer />
  </div>
);



// Scroll to top on route change
const ScrollToTop = () => {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
};

export default function App() {
  const { marketProducts } = useFarmData();
  
  return (
    <BrowserRouter>
      <ScrollToTop />
      <Routes>
        {/* Priority Routes: Professional Marketplace */}
        <Route path="/marketplace" element={<GlobalMarketplace products={marketProducts} />} />

        {/* Core ERP System */}
        <Route path="/app/*" element={<SystemApp />} />
        
        {/* Marketing Website */}
        <Route path="/" element={<MainSiteLayout><Home /></MainSiteLayout>} />
        <Route path="/features" element={<MainSiteLayout><FeaturePage /></MainSiteLayout>} />
        <Route path="/pricing" element={<MainSiteLayout><PricingPage /></MainSiteLayout>} />
        <Route path="/about" element={<MainSiteLayout><AboutPage /></MainSiteLayout>} />
        <Route path="/security" element={<MainSiteLayout><SecurityPage /></MainSiteLayout>} />
        <Route path="/faq" element={<MainSiteLayout><FAQPage /></MainSiteLayout>} />
        <Route path="/pos-financials" element={<MainSiteLayout><POSAccounting /></MainSiteLayout>} />
        <Route path="/developer" element={<MainSiteLayout><DeveloperProfile /></MainSiteLayout>} />
        <Route path="/roadmap" element={<MainSiteLayout><ProductRoadmap /></MainSiteLayout>} />
        <Route path="/support" element={<MainSiteLayout><TechnicalHelpPage /></MainSiteLayout>} />
        <Route path="/faq" element={<MainSiteLayout><FAQPage /></MainSiteLayout>} />
        <Route path="/terms" element={<MainSiteLayout><TermsPage /></MainSiteLayout>} />
        <Route path="/privacy" element={<MainSiteLayout><PrivacyPolicyPage /></MainSiteLayout>} />
        
        {/* Catch All */}
        <Route path="*" element={<MainSiteLayout><Home /></MainSiteLayout>} />
      </Routes>
    </BrowserRouter>
  );
}
