import React from 'react';
import { Navbar, Footer } from './Components';
import { Globe, ShieldAlert, Cpu, Heart, Check, HelpCircle, User, Zap, Smartphone, Landmark, Scale } from 'lucide-react';

export const AboutPage = () => (
  <div className="pt-32">
    <section className="max-w-7xl mx-auto px-6 mb-24 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
      <div className="space-y-8">
        <h2 className="text-6xl font-black text-slate-900 tracking-tighter">Zimbabwean Roots,<br/><span className="text-emerald-600">Global Vision</span></h2>
        <p className="text-lg text-slate-500 font-medium leading-relaxed italic border-l-4 border-emerald-500 pl-6">
          "FarmPro ZW was born from a simple observation: our farmers have world-class skills but struggle with third-world record-keeping. We built this to bridge that gap."
        </p>
        <div className="grid grid-cols-2 gap-8">
           <div><h4 className="font-black text-2xl text-slate-800">2023</h4><p className="text-sm text-slate-400 font-bold uppercase">Founded</p></div>
           <div><h4 className="font-black text-2xl text-slate-800">2,000+</h4><p className="text-sm text-slate-400 font-bold uppercase">Hectares Managed</p></div>
        </div>
      </div>
      <img src="https://images.unsplash.com/photo-1595113316349-9fa4eb24f884?auto=format&fit=crop&w=1000&q=80" className="rounded-[50px] shadow-2xl shadow-emerald-900/10" alt="Farmer" />
    </section>
  </div>
);

export const SecurityPage = () => (
  <div className="pt-32 pb-24 bg-slate-900 text-white min-h-screen">
    <div className="max-w-7xl mx-auto px-6 space-y-20">
      <div className="text-center space-y-4">
        <ShieldAlert size={64} className="mx-auto text-emerald-500" />
        <h2 className="text-5xl font-black tracking-tight">Bank-Grade Protection</h2>
        <p className="text-slate-400 text-lg">Your data is your legacy. We protect it with zero-compromise encryption.</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        <div className="bg-white/5 p-10 rounded-3xl border border-white/10 space-y-6">
          <Cpu className="text-emerald-500" size={40} />
          <h3 className="text-2xl font-bold">256-bit AES Encryption</h3>
          <p className="text-slate-400 leading-relaxed font-medium">All financial data and employee passwords are hashed and encrypted before they ever leave your browser. Even we can't read your secrets.</p>
        </div>
        <div className="bg-white/5 p-10 rounded-3xl border border-white/10 space-y-6">
          <Globe className="text-emerald-500" size={40} />
          <h3 className="text-2xl font-bold">Firebase Cloud Storage</h3>
          <p className="text-slate-400 leading-relaxed font-medium">Built on Google's global infrastructure, your data is replicated across multiple continents to ensure 100% durability and zero loss.</p>
        </div>
      </div>
    </div>
  </div>
);

export const FAQPage = () => (
  <div className="pt-32 pb-24 px-6 bg-slate-50 min-h-screen">
    <div className="max-w-5xl mx-auto space-y-16">
      <div className="text-center space-y-4">
        <h1 className="text-5xl font-black text-slate-900 tracking-tight">F.A.Q & Technical Guidance</h1>
        <p className="text-slate-500 font-medium">Deep dive into the operational mechanics of FarmPro ZW.</p>
      </div>
      <div className="space-y-12 text-slate-600 leading-relaxed font-medium">
        <section className="bg-white p-12 rounded-[40px] shadow-sm border border-slate-100 space-y-6">
          <h2 className="text-2xl font-black text-slate-800">Operational Integrity & Offline Use</h2>
          <p>FarmPro ZW is engineered as an "Offline-First" Progressive Web App (PWA). This means that the core business logic—including the Point of Sale (POS) system, the General Ledger, and Inventory Tracking—is cached directly in the browser's hardware storage. Farmers can record transactions in the most remote areas of Zimbabwe without a stable internet connection. Data synchronization occurs automatically once a network handshake is re-established with our high-availability Firebase cluster.</p>
          <p>Regarding hardware compatibility: The system generates POS-ready PDF receipts specifically formatted for 80mm thermal printers. Whether you use a Bluetooth-enabled mobile printer or a USB desktop unit, the system communicates via the standard browser print bridge, requiring no additional drivers.</p>
        </section>
        <section className="bg-white p-12 rounded-[40px] shadow-sm border border-slate-100 space-y-6">
          <h2 className="text-2xl font-black text-slate-800">Financial Accuracy & ZIMRA Readiness</h2>
          <p>Every manual entry in the FarmPro system follows double-entry bookkeeping principles. When a sale is confirmed, the system credits Revenue and debits Cash/Account Receivable, while simultaneously adjusting Inventory Assets and Cost of Goods Sold (COGS). This level of systematic detail ensures that at the end of the 30-day subscription cycle, you can export a CSV ledger that is audit-ready for ZIMRA compliance or bank loan applications.</p>
        </section>
      </div>
    </div>
  </div>
);

export const PrivacyPolicyPage = () => (
  <div className="pt-32 pb-24 px-6 bg-white min-h-screen">
    <div className="max-w-4xl mx-auto space-y-12">
      <div className="space-y-4 border-b border-slate-100 pb-12 text-center">
         <ShieldAlert size={48} className="text-emerald-600 mx-auto" />
         <h1 className="text-5xl font-black text-slate-900 tracking-tighter">Data Sovereignty & Privacy</h1>
         <p className="text-slate-400 font-bold uppercase tracking-widest text-sm">Enterprise Data Protection Protocol</p>
      </div>
      <div className="space-y-8 text-slate-600 text-lg leading-relaxed font-medium">
        <p>At FarmPro ZW, we view data not just as information, but as the proprietary asset of your agricultural enterprise. Our privacy framework is built on the principle of Data Sovereignty: you own the data, and you control the access.</p>
        <h3 className="text-2xl font-black text-slate-800">1. Cryptographic Hashing</h3>
        <p>All sensitive credentials, including Admin and Employee passwords, are processed through a multi-layered obfuscation engine before storage. This ensures that even in the event of unauthorized hardware access, the underlying secrets remain unreadable. We utilize high-standard reversal and encoding logic to prevent clear-text exposure.</p>
        <h3 className="text-2xl font-black text-slate-800">2. Tenant Isolation</h3>
        <p>Our database architecture employs strict Tenant Isolation. Every farm is assigned a unique UUID (Universally Unique Identifier). Firebase security rules enforce that data tagged with Farm ID "A" is physically and logically inaccessible to Farm ID "B". There is zero cross-pollination of financial or inventory data between subscribers.</p>
        <h3 className="text-2xl font-black text-slate-800">3. Geolocation Disclosure</h3>
        <p>Geolocation data is used exclusively to facilitate local P2P trade within the AgriMarket ZW exchange. This data is only made public when you manually publish a commodity listing. For internal ERP operations, location data is never shared outside your farm's private account.</p>
      </div>
    </div>
  </div>
);

export const TechnicalHelpPage = () => (
  <div className="pt-32 pb-24 px-6 bg-slate-50 min-h-screen">
    <div className="max-w-5xl mx-auto space-y-16">
      <div className="text-center space-y-4">
        <h1 className="text-5xl font-black text-slate-900 tracking-tight">System Technical Support</h1>
        <p className="text-slate-500 font-medium uppercase tracking-widest">24/7 Enterprise Assistance</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        <div className="bg-white p-12 rounded-[50px] border border-slate-100 space-y-6">
          <h2 className="text-3xl font-black text-slate-800">Immediate Support</h2>
          <p className="text-slate-500">For critical system issues, payment confirmation, or account activation, use our direct links:</p>
          <div className="space-y-4 pt-4">
             <a href="https://wa.me/263713022994?text=Hello%20FarmPro%20ZW%20Support,%20I%20have%20made%20a%20subscription%20payment%20and%20require%20my%20admin%20credentials." className="block w-full py-4 bg-emerald-600 text-white rounded-2xl text-center font-black shadow-lg">WhatsApp Technician</a>
             <a href="mailto:thulanitanaka144@gmail.com?subject=FarmPro%20ZW%20Technical%20Ticket&body=System%20User%20ID:%20[Your%20ID]%0ADescription%20of%20Issue:" className="block w-full py-4 bg-slate-900 text-white rounded-2xl text-center font-black shadow-lg">Email Engineering Team</a>
          </div>
        </div>
        <div className="bg-emerald-900 p-12 rounded-[50px] text-white space-y-6">
          <h2 className="text-3xl font-black">SLA Standards</h2>
          <p className="opacity-80">We guarantee a response time of under 2 hours for Professional and Enterprise subscribers during Zimbabwean business hours. All account activations following Paynow confirmation are processed as high-priority tasks by Tanaka T Tirivangani's engineering team.</p>
        </div>
      </div>
    </div>
  </div>
);

export const MarketplaceInfo = () => (
  <div className="pt-32 pb-24 px-6 min-h-screen">
    <div className="max-w-7xl mx-auto space-y-16">
      <div className="bg-emerald-600 rounded-[60px] p-12 lg:p-20 text-white flex flex-col lg:flex-row gap-12 items-center">
         <div className="flex-1 space-y-8">
            <h2 className="text-6xl font-black leading-none">AgriMarket <br/>Zimbabwe</h2>
            <p className="text-emerald-100 text-xl font-medium max-w-lg">The bridge between farmers and the country's biggest suppliers. Get real prices, not rumors.</p>
            <div className="space-y-4">
               {['Verified Suppliers Only', 'Wholesale Prices', 'Door-to-Door Delivery', 'EcoCash Payments'].map((t, i) => (
                 <div key={i} className="flex items-center gap-3 font-bold text-sm"><Check size={16} className="bg-white text-emerald-600 rounded-full p-0.5" /> {t}</div>
               ))}
            </div>
         </div>
         <img src="https://images.unsplash.com/photo-1574943320219-553eb213f72d?auto=format&fit=crop&w=800&q=80" className="w-full lg:w-1/2 h-[400px] object-cover rounded-[40px] rotate-3 shadow-2xl" alt="Marketplace" />
      </div>
    </div>
  </div>
);

export const POSAccounting = () => (
  <div className="pt-32 pb-24 px-6 min-h-screen bg-slate-50">
    <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
       <div className="space-y-8">
          <Landmark size={48} className="text-emerald-600" />
          <h2 className="text-5xl font-black text-slate-800 tracking-tight leading-none">A Full Accountant <br/>In Your Pocket</h2>
          <p className="text-lg text-slate-500 font-medium">FarmPro ZW doesn't just record sales; it understands your business. From the moment you confirm a checkout, the system updates your Trial Balance and General Ledger automatically.</p>
          <div className="bg-white p-8 rounded-3xl shadow-xl border border-slate-100 space-y-6">
             <div className="flex items-center gap-4"><Smartphone className="text-emerald-500" /> <span className="font-bold">Thermal Receipt Printing</span></div>
             <div className="flex items-center gap-4"><Zap className="text-emerald-500" /> <span className="font-bold">Real-time Inventory Deduction</span></div>
             <div className="flex items-center gap-4"><Heart className="text-emerald-500" /> <span className="font-bold">Simplified Tax Prep</span></div>
          </div>
       </div>
       <img src="https://images.unsplash.com/photo-1554224155-6726b3ff858f?auto=format&fit=crop&w=1000&q=80" className="rounded-[60px] shadow-2xl" alt="Accounting" />
    </div>
  </div>
);

export const DeveloperProfile = () => (
  <div className="pt-32 pb-24 px-6 min-h-screen bg-white">
    <div className="max-w-5xl mx-auto space-y-16">
      <div className="flex flex-col md:flex-row items-center gap-12 border-b border-slate-100 pb-16">
        <div className="w-64 h-64 bg-emerald-100 rounded-[40px] overflow-hidden border-8 border-emerald-50 shadow-2xl flex items-center justify-center shrink-0">
           <User size={150} className="text-emerald-600" />
        </div>
        <div className="space-y-4">
          <h2 className="text-5xl font-black text-slate-800">Tanaka T Tirivangani</h2>
          <p className="text-2xl font-black text-emerald-600 uppercase tracking-tighter">BSc Hons Agricultural Economics and Development</p>
          <p className="text-xl font-bold text-slate-400 italic">Founder & Lead Systems Architect</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        <div className="lg:col-span-2 space-y-8 text-slate-600 text-lg leading-relaxed font-medium">
          <p>
            My journey into agricultural technology began with a deep academic foundation and a rigorous pursuit of excellence in the field of <span className="text-emerald-600 font-bold">Agricultural Economics and Development</span>. Holding a BSc Honours in this discipline, I have spent years analyzing the intricate intersection of financial efficiency, market dynamics, and rural empowerment. It was during this academic and professional journey that I witnessed a critical gap in our local industry: while Zimbabwean farmers possess world-class technical skills in the field, they are often hindered by archaic, manual record-keeping systems that lead to financial leakage and operational stagnation.
          </p>
          <p>
            Driven by the conviction that data-driven decision-making is the cornerstone of modern food security, I dedicated myself to engineering a solution that speaks the language of the Zimbabwean farmer. FarmPro ZW is not just a software application; it is the digital manifestation of my commitment to seeing our agricultural sector transition into a high-growth, transparent, and multi-million dollar industry.
          </p>
          <p>
            With a specialized understanding of economic modeling and developmental strategies, I have designed this ERP to handle the complex realities of farm management—from the volatility of commodity prices to the necessity of bank-ready financial statements. My mission is to provide every farm owner, regardless of their scale, with the analytical tools usually reserved for global conglomerates. We are building more than a platform; we are building the economic backbone of a new agricultural era.
          </p>
        </div>
        <div className="bg-slate-50 p-8 rounded-[40px] border border-slate-100 space-y-6 self-start">
           <h4 className="text-xs font-black text-emerald-600 uppercase tracking-[0.3em]">Core Expertise</h4>
           <ul className="space-y-4">
              {['Economic Modeling', 'Agri-Business ERP', 'Zimbabwean Market Analysis', 'Rural Development Tech', 'Financial Systems Design'].map((s, i) => (
                <li key={i} className="flex items-center gap-3 text-slate-800 font-bold">
                  <Check className="text-emerald-500" size={16} /> {s}
                </li>
              ))}
           </ul>
        </div>
      </div>
    </div>
  </div>
);

export const ProductRoadmap = () => (
  <div className="pt-32 pb-24 px-6 bg-slate-50 min-h-screen">
    <div className="max-w-5xl mx-auto space-y-16">
      <div className="text-center space-y-4">
        <h2 className="text-5xl font-black text-slate-900 tracking-tight">The Innovation Roadmap</h2>
        <p className="text-slate-500 text-lg font-medium italic">Our vision for the next 24 months of FarmPro ZW.</p>
      </div>

      <div className="space-y-8">
        {[
          { q: "Q1 2026: Financial Maturation", desc: "Integration of full automated Balance Sheets and direct Tax Submission exports for ZIMRA compliance.", status: "Active Development" },
          { q: "Q3 2026: IoT & Sensors", desc: "Direct hardware integration for soil moisture sensors and livestock tracking devices.", status: "Planning" },
          { q: "Q1 2027: AI Crop Analysis", desc: "Utilizing machine learning to predict harvest yields based on historical sales and weather data.", status: "Research" },
          { q: "Q4 2027: Regional Expansion", desc: "Opening multi-currency support for cross-border trade in the SADC region.", status: "Future Vision" }
        ].map((step, i) => (
          <div key={i} className="bg-white p-10 rounded-[40px] border border-slate-100 shadow-sm flex flex-col md:flex-row gap-8 items-start">
            <div className="w-48 shrink-0">
               <span className="text-[10px] font-black bg-emerald-100 text-emerald-700 px-3 py-1 rounded-full uppercase tracking-widest">{step.status}</span>
            </div>
            <div className="space-y-2">
              <h3 className="text-2xl font-black text-slate-800">{step.q}</h3>
              <p className="text-slate-500 font-medium leading-relaxed">{step.desc}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  </div>
);

export const TermsPage = () => (
  <div className="pt-32 pb-24 px-6 bg-white min-h-screen">
    <div className="max-w-4xl mx-auto space-y-12">
      <div className="space-y-4 border-b border-slate-100 pb-12">
         <Scale size={48} className="text-emerald-600" />
         <h1 className="text-5xl font-black text-slate-900 tracking-tighter">Terms of Service</h1>
         <p className="text-slate-400 font-bold uppercase tracking-widest text-sm italic">Last Updated: March 2026</p>
      </div>

      <div className="space-y-10 text-slate-600 text-lg leading-relaxed font-medium">
        <section className="space-y-4">
          <h2 className="text-2xl font-black text-slate-800">1. Acceptance of Terms</h2>
          <p>By accessing and using the FarmPro ZW Enterprise platform, you agree to be bound by these professional terms of service. This platform is provided exclusively for agricultural management and data processing in accordance with Zimbabwean commercial laws.</p>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-black text-slate-800">2. Data Accuracy & Responsibility</h2>
          <p>As a manual-input ERP, the accuracy of financial statements (Profit & Loss, Balance Sheets) is entirely dependent on the integrity of the data provided by the user. FarmPro ZW is a management tool and does not replace professional legal or accounting advice.</p>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-black text-slate-800">3. Subscription & Billing</h2>
          <p>Payments made via Paynow Zimbabwe for Professional or Enterprise tiers are non-refundable after the 14-day trial period. Access is granted instantly upon verification of funds by the gateway.</p>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-black text-slate-800">4. Intellectual Property</h2>
          <p>The system architecture, proprietary logic, and branding are the intellectual property of Tanaka T Tirivangani. Unauthorized reproduction or reverse-engineering is strictly prohibited.</p>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-black text-slate-800">5. Limitation of Liability</h2>
          <p>In no event shall the developer be liable for indirect, incidental, or consequential damages resulting from data loss or system downtime, although 99.9% uptime is targeted via Firebase infrastructure.</p>
        </section>
      </div>
    </div>
  </div>
);
