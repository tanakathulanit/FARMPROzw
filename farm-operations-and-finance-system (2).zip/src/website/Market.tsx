import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ShoppingBag, MapPin, Truck, User as UserIcon, Search, Camera, Phone, LogOut, Plus, Smartphone, MessageSquare, Trash2 } from 'lucide-react';
import { MarketProduct, GlobalUser } from '../types';
import { useFarmData } from '../hooks/useFarmData';
import { format } from 'date-fns';

export const MarketNavbar = ({ onAuthClick, onDashboardClick, isDashboardActive }: { onAuthClick?: () => void, onDashboardClick?: () => void, isDashboardActive?: boolean }) => {
  const { currentMarketUser, logoutMarketUser } = useFarmData();
  
  return (
    <nav className="fixed top-0 w-full z-[100] bg-slate-900 border-b border-white/10 px-8 py-5">
      <div className="max-w-7xl mx-auto flex justify-between items-center">
        <Link to="/marketplace" className="flex items-center gap-3">
          <div className="bg-emerald-500 p-2 rounded-xl shadow-lg shadow-emerald-500/20">
            <ShoppingBag className="text-white" size={24} />
          </div>
          <span className="text-2xl font-black text-white tracking-tighter uppercase italic text-lg sm:text-2xl">AgriMarket <span className="text-emerald-500">ZW</span></span>
        </Link>
        
        <div className="flex items-center gap-4 sm:gap-6">
          {currentMarketUser ? (
            <div className="flex items-center gap-3 sm:gap-4">
              <button 
                onClick={onDashboardClick}
                className={`px-3 py-1.5 sm:px-5 sm:py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${isDashboardActive ? 'bg-white text-slate-900' : 'bg-white/10 text-emerald-400 hover:bg-white/20'}`}
              >
                {isDashboardActive ? '← Market' : 'My Dashboard'}
              </button>
              <div className="flex flex-col items-end hidden sm:flex">
                <span className="text-xs font-black text-white leading-none mb-1">{currentMarketUser.name}</span>
                <span className="text-[9px] font-bold text-emerald-500 uppercase tracking-tighter">{currentMarketUser.role}</span>
              </div>
              <button 
                onClick={logoutMarketUser}
                className="p-2 bg-white/5 hover:bg-rose-500/10 text-slate-400 hover:text-rose-500 rounded-xl transition-all border border-white/5"
              >
                <LogOut size={16} />
              </button>
            </div>
          ) : (
            <button 
              onClick={onAuthClick}
              className="bg-emerald-600 text-white px-5 py-2 rounded-full text-[10px] font-black uppercase tracking-widest shadow-lg shadow-emerald-900/40 hover:bg-emerald-500"
            >
              Sign In
            </button>
          )}
        </div>
      </div>
    </nav>
  );
};

export const MarketRegistration = ({ mode, setMode, onClose }: { mode: 'login' | 'register', setMode: (m: 'login' | 'register') => void, onClose: () => void }) => {
  const { registerMarketUser, loginMarketUser, addLog } = useFarmData();
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    const formData = new FormData(e.currentTarget as HTMLFormElement);
    
    if (mode === 'register') {
      const email = formData.get('email') as string;
      const pass = formData.get('pass') as string;
      const name = formData.get('name') as string;
      const phone = formData.get('phone') as string;

      if (!email || !pass || !name || !phone) {
        setError('Missing required fields');
        return;
      }

      registerMarketUser({
        name,
        email,
        password: pass,
        phone,
        role: formData.get('role') as any,
        farmName: formData.get('farm') as string,
        subscriptionStatus: 'active',
        subscriptionTier: 'free',
        farmId: 'EXT_' + Date.now()
      });
      addLog('Market', `New marketplace participant registered: ${name} (${formData.get('role')})`);
      alert("Account Created! You can now login.");
      setMode('login');
    } else {
      const success = loginMarketUser(formData.get('email') as string, formData.get('pass') as string);
      if (success) {
        addLog('Market', `Marketplace participant login: ${formData.get('email')}`);
        onClose();
      } else {
        setError('Invalid credentials.');
      }
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-950/90 backdrop-blur-md z-[200] flex items-center justify-center p-4">
      <div className="bg-white rounded-[48px] shadow-2xl w-full max-w-lg overflow-hidden animate-in zoom-in duration-300">
        <div className="p-12 bg-emerald-600 text-white text-center space-y-2 relative">
           <button onClick={onClose} className="absolute top-6 right-8 text-white/50 hover:text-white font-black text-xl">×</button>
           <h2 className="text-3xl font-black uppercase tracking-tighter">{mode === 'login' ? 'Welcome Back' : 'Market Access'}</h2>
           <p className="opacity-80 font-medium text-emerald-100 italic">Access the professional commodity network</p>
        </div>

        <div className="flex bg-slate-50 border-b border-slate-100">
           <button onClick={() => setMode('login')} className={`flex-1 py-4 text-xs font-black uppercase tracking-widest ${mode === 'login' ? 'bg-white text-emerald-600 border-t-2 border-emerald-600' : 'text-slate-400'}`}>Login</button>
           <button onClick={() => setMode('register')} className={`flex-1 py-4 text-xs font-black uppercase tracking-widest ${mode === 'register' ? 'bg-white text-emerald-600 border-t-2 border-emerald-600' : 'text-slate-400'}`}>Register</button>
        </div>

        <form onSubmit={handleSubmit} className="p-10 space-y-4">
           {mode === 'register' && (
             <>
               <div className="grid grid-cols-2 gap-4">
                 <input name="name" placeholder="Full Name" required className="w-full p-4 rounded-2xl border-2 border-slate-50 outline-none focus:border-emerald-500 font-bold bg-slate-50" />
                 <input name="farm" placeholder="Farm/Company" className="w-full p-4 rounded-2xl border-2 border-slate-50 outline-none focus:border-emerald-500 font-bold bg-slate-50" />
               </div>
               <div className="grid grid-cols-2 gap-4">
                 <select name="role" className="w-full p-4 rounded-2xl border-2 border-slate-50 outline-none focus:border-emerald-500 font-bold bg-slate-50">
                    <option value="seller">Seller</option>
                    <option value="buyer">Buyer</option>
                    <option value="transporter">Transporter</option>
                 </select>
                 <input name="phone" placeholder="WhatsApp Number" required className="w-full p-4 rounded-2xl border-2 border-slate-50 outline-none focus:border-emerald-500 font-bold bg-slate-50" />
               </div>
             </>
           )}
           <input name="email" type="email" placeholder="Email Address" required className="w-full p-4 rounded-2xl border-2 border-slate-50 outline-none focus:border-emerald-500 font-bold bg-slate-50" />
           <input name="pass" type="password" placeholder="Password" required className="w-full p-4 rounded-2xl border-2 border-slate-50 outline-none focus:border-emerald-500 font-bold bg-slate-50" />
           {error && <p className="text-rose-500 text-xs font-bold px-2">{error}</p>}
           <button className="w-full py-5 bg-slate-900 text-white rounded-[24px] font-black text-lg shadow-xl hover:bg-emerald-600 transition-all uppercase tracking-tighter">
             {mode === 'login' ? 'Secure Login' : 'Create My Account'}
           </button>
        </form>
      </div>
    </div>
  );
};

export const GlobalMarketplace = ({ products, isERP = false, currentUser }: { products: MarketProduct[], isERP?: boolean, currentUser?: any }) => {
  const { currentMarketUser, addMarketProduct, deleteMarketProduct } = useFarmData();
  const [category, setCategory] = useState('All');
  const [search, setSearch] = useState('');
  const [userLocation, setUserLocation] = useState<{lat: number, lng: number, name: string} | null>(null);
  
  const [authMode, setAuthMode] = useState<'login' | 'register' | null>(null);
  const [isAdding, setIsAdding] = useState(false);
  const [isDashboard, setIsDashboard] = useState(false);

  const activeUser = currentUser || currentMarketUser;

  useEffect(() => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (pos) => setUserLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude, name: "Current Location" }),
        () => setUserLocation({ lat: -17.82, lng: 31.05, name: "Harare, ZW" })
      );
    }
  }, []);

  const filtered = products.filter(p => 
    (category === 'All' || p.category === category) &&
    (p.name.toLowerCase().includes(search.toLowerCase()) || p.description.toLowerCase().includes(search.toLowerCase()))
  );

  // Visitor Dashboard Logic
  if (activeUser && isDashboard && !isERP) {
    return (
      <div className="bg-slate-50 min-h-screen">
        <MarketNavbar onDashboardClick={() => setIsDashboard(false)} isDashboardActive={true} />
        <div className="max-w-7xl mx-auto pt-32 p-8 space-y-12">
           <header className="flex flex-col md:row justify-between items-start md:items-end gap-6">
              <div>
                <h2 className="text-5xl font-black text-slate-900 tracking-tighter">Market Console</h2>
                <p className="text-slate-500 font-medium italic">Welcome back, {activeUser.name}. Manage your global trades.</p>
              </div>
              <button onClick={() => setIsAdding(true)} className="bg-emerald-600 text-white px-10 py-4 rounded-2xl font-black shadow-xl hover:bg-emerald-700 transition-all flex items-center gap-3">
                 <Plus size={24} /> New Market Listing
              </button>
           </header>

           <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
              <div className="space-y-6">
                 <div className="bg-white p-8 rounded-[40px] border border-slate-100 shadow-sm space-y-2">
                    <h3 className="font-black text-slate-400 uppercase text-[10px] tracking-[0.2em]">Profile Identity</h3>
                    <div className="text-2xl font-black text-slate-800 tracking-tight capitalize">{activeUser.role}</div>
                    <div className="text-xs font-bold text-emerald-600 uppercase">{activeUser.farmName || 'Independent Trader'}</div>
                 </div>
                 <div className="bg-slate-900 p-8 rounded-[40px] text-white space-y-4">
                    <Smartphone className="text-emerald-500" size={32} />
                    <h3 className="font-bold text-lg">Active Location</h3>
                    <p className="text-slate-400 text-xs font-medium">Automatic Geopin active. Your listings are being prioritized for buyers near {userLocation?.name}.</p>
                 </div>
              </div>

              <div className="lg:col-span-2 bg-white p-12 rounded-[40px] border border-slate-100 shadow-sm space-y-8">
                 <h3 className="text-2xl font-black text-slate-800">My Listings</h3>
                 <div className="space-y-4">
                    {products.filter(p => p.sellerId === activeUser.id).map(p => (
                      <div key={p.id} className="flex justify-between items-center p-6 bg-slate-50 rounded-3xl border border-slate-100 group transition-all hover:bg-white hover:shadow-lg">
                        <div className="flex items-center gap-6">
                           <div className="w-16 h-16 rounded-2xl bg-white overflow-hidden border border-slate-100 shadow-sm">
                              <img src={p.imageUrl} className="w-full h-full object-cover" alt="" />
                           </div>
                           <div>
                              <div className="font-black text-slate-800 text-lg">{p.name}</div>
                              <div className="flex items-center gap-2 text-[10px] font-black text-emerald-600 uppercase tracking-widest">
                                 {p.type === 'service' ? <Truck size={12}/> : <Plus size={12}/>} {p.category}
                              </div>
                           </div>
                        </div>
                        <div className="text-right flex flex-col items-end gap-3">
                           <div className="space-y-1">
                             <div className="font-black text-slate-900 text-xl">${p.price}</div>
                             <div className="text-[10px] font-bold text-slate-400 uppercase">{format(new Date(p.date), 'MMM dd')}</div>
                           </div>
                           <button 
                             onClick={() => { if(confirm("Permanently remove this listing?")) deleteMarketProduct(p.id) }}
                             className="p-2 text-slate-300 hover:text-rose-500 hover:bg-rose-50 rounded-lg transition-all"
                           >
                             <Trash2 size={16} />
                           </button>
                        </div>
                      </div>
                    ))}
                    {products.filter(p => p.sellerId === activeUser.id).length === 0 && (
                      <div className="py-20 text-center space-y-4 border-2 border-dashed border-slate-100 rounded-[40px]">
                         <ShoppingBag className="mx-auto text-slate-200" size={48} />
                         <p className="text-slate-400 font-bold italic">You have no active listings. Click the button above to start.</p>
                      </div>
                    )}
                 </div>
              </div>
           </div>
        </div>
        
        {isAdding && (
          <div className="fixed inset-0 bg-slate-950/95 backdrop-blur-xl z-[300] flex items-center justify-center p-4">
            <div className="bg-white rounded-[50px] shadow-2xl w-full max-w-xl overflow-hidden animate-in zoom-in duration-300">
               <div className="p-12 bg-emerald-600 text-white text-center relative">
                  <button onClick={() => setIsAdding(false)} className="absolute top-6 right-8 text-white/50 hover:text-white font-black text-xl">×</button>
                  <h2 className="text-3xl font-black uppercase tracking-tighter">New Market Listing</h2>
                  <p className="opacity-80 font-medium text-emerald-100 italic">Visible to real farmers nationwide</p>
               </div>
               <form 
                onSubmit={(e) => {
                  e.preventDefault();
                  const formData = new FormData(e.currentTarget as HTMLFormElement);
                  addMarketProduct({
                    name: formData.get('name') as string,
                    price: Number(formData.get('price')),
                    category: formData.get('category') as string,
                    description: formData.get('desc') as string,
                    sellerId: activeUser.id,
                    sellerName: activeUser.name,
                    sellerPhone: activeUser.phone,
                    farmId: activeUser.farmId || 'VISITOR_LISTING',
                    date: new Date().toISOString(),
                    location: { lat: userLocation?.lat || 0, lng: userLocation?.lng || 0, name: userLocation?.name || 'Zimbabwe' },
                    imageUrl: formData.get('img') as string,
                    type: (formData.get('category') as string).includes('Transport') ? 'service' : 'product'
                  });
                  setIsAdding(false);
                }}
                className="p-12 space-y-4"
              >
                <input name="name" placeholder="Name of Product or Service" required className="w-full p-4 rounded-2xl border-2 border-slate-50 outline-none focus:border-emerald-500 font-bold bg-slate-50" />
                <div className="grid grid-cols-2 gap-4">
                  <input name="price" type="number" step="0.01" placeholder="Price (USD)" required className="w-full p-4 rounded-2xl border-2 border-slate-50 outline-none focus:border-emerald-500 font-bold bg-slate-50" />
                  <select name="category" className="w-full p-4 rounded-2xl border-2 border-slate-50 outline-none focus:border-emerald-500 font-bold bg-slate-50">
                      <option>Grains</option>
                      <option>Livestock</option>
                      <option>Vegetables</option>
                      <option>Poultry</option>
                      <option>Transport Services</option>
                      <option>Agri-Equipment</option>
                      <option>Consultancy</option>
                  </select>
                </div>
                <textarea name="desc" placeholder="Details (Quality, location, logistics)..." required className="w-full p-4 h-32 rounded-2xl border-2 border-slate-50 outline-none focus:border-emerald-500 font-bold bg-slate-50" />
                <input name="img" placeholder="Real Photo Link (URL)" required className="w-full p-4 rounded-2xl border-2 border-slate-50 outline-none focus:border-emerald-500 font-bold bg-slate-50" />
                <button type="submit" className="w-full py-5 bg-slate-900 text-white rounded-[24px] font-black uppercase shadow-xl hover:bg-emerald-600 transition-all tracking-tighter">Publish to Exchange</button>
              </form>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className={`${isERP ? 'bg-slate-50 p-0 min-h-screen' : 'bg-slate-950 min-h-screen pb-20'}`}>
      {!isERP && <MarketNavbar onAuthClick={() => setAuthMode('login')} onDashboardClick={() => setIsDashboard(true)} isDashboardActive={false} />}
      
      {!activeUser && !isERP && (
        <div className="fixed top-24 left-1/2 -translate-x-1/2 z-[90] animate-in slide-in-from-top-4 duration-500">
           <div className="bg-emerald-500 text-slate-950 px-6 py-2 rounded-full font-black text-[10px] uppercase tracking-[0.2em] shadow-2xl flex items-center gap-3">
              <Smartphone size={14} /> Global Visitor Hub • Login to Start Trading
           </div>
        </div>
      )}

      <div className={`${isERP ? 'pt-8 pb-12' : 'pt-48 pb-32'} px-6 relative overflow-hidden text-center`}>
        {!isERP && <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1523348837708-15d4a09cfac2?auto=format&fit=crop&w=1920&q=80')] bg-cover bg-center opacity-10"></div>}
        {!isERP && <div className="absolute inset-0 bg-gradient-to-b from-slate-950 via-slate-950/80 to-slate-950"></div>}
        
        <div className="max-w-7xl mx-auto space-y-12 relative z-10">
          <div className="space-y-6">
            <h1 className={`text-7xl lg:text-[120px] font-black tracking-tighter leading-[0.8] ${isERP ? 'text-slate-900' : 'text-white'}`}>
              AgriMarket <span className="text-emerald-500 italic">ZW</span>
            </h1>
            <p className="text-slate-500 text-xl font-medium max-w-2xl mx-auto italic">
              "Connecting the soil to the soul of the digital economy."
            </p>
          </div>
          
          <div className={`max-w-4xl mx-auto p-3 rounded-[40px] shadow-2xl flex flex-col md:flex-row gap-3 ${isERP ? 'bg-white border border-slate-200' : 'bg-white/5 backdrop-blur-xl border border-white/10'}`}>
            <div className="flex-1 relative">
              <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-600" size={24} />
              <input 
                type="text" 
                placeholder="What are you sourcing today?" 
                className={`w-full pl-16 pr-4 py-5 rounded-[32px] bg-transparent outline-none font-bold text-lg ${isERP ? 'text-slate-900 placeholder:text-slate-300' : 'text-white placeholder:text-slate-700'}`}
                value={search}
                onChange={e => setSearch(e.target.value)}
              />
            </div>
            <div className="flex gap-3">
              <select 
                className={`px-8 py-5 rounded-[32px] font-black outline-none border cursor-pointer appearance-none shadow-xl ${isERP ? 'bg-slate-50 border-slate-100 text-slate-600' : 'bg-slate-900 border-white/5 text-slate-300'}`}
                value={category}
                onChange={e => setCategory(e.target.value)}
              >
                <option>All Assets</option>
                <option>Grains</option>
                <option>Livestock</option>
                <option>Vegetables</option>
                <option>Poultry</option>
                <option>Transport Services</option>
                <option>Agri-Equipment</option>
                <option>Consultancy</option>
              </select>
              {activeUser ? (
                <button onClick={() => isERP ? setIsAdding(true) : setIsDashboard(true)} className="bg-emerald-500 text-slate-950 px-10 py-5 rounded-[32px] font-black hover:bg-emerald-400 transition-all text-lg flex items-center gap-2">
                   <Plus size={24} /> {isERP ? 'List Produce' : 'Manage Listings'}
                </button>
              ) : (
                <button onClick={() => setAuthMode('register')} className="bg-white text-slate-950 px-10 py-5 rounded-[32px] font-black hover:bg-emerald-50 transition-all text-lg uppercase tracking-tighter">
                   Join Market
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 mb-32">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
          {filtered.map(product => (
            <div key={product.id} className={`rounded-[48px] overflow-hidden border shadow-2xl transition-all group flex flex-col ${isERP ? 'bg-white border-slate-100' : 'bg-slate-900 border-white/5 hover:border-emerald-500/50'}`}>
              <div className="h-80 relative overflow-hidden">
                <img 
                  src={product.imageUrl || `https://images.unsplash.com/photo-1523348837708-15d4a09cfac2?auto=format&fit=crop&w=800&q=80&sig=${product.id}`} 
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-[2s]"
                  alt={product.name}
                />
                <div className="absolute top-8 right-8 bg-emerald-500 text-slate-950 px-6 py-2 rounded-full font-black text-[10px] uppercase tracking-widest shadow-2xl">
                  {product.category}
                </div>
                <div className="absolute bottom-8 left-8 bg-slate-950/90 backdrop-blur-2xl px-5 py-2.5 rounded-2xl flex items-center gap-3 text-white text-xs font-black border border-white/10 shadow-2xl">
                  <MapPin size={16} className="text-emerald-500" /> 
                  {product.location?.name || 'Zimbabwe Region'}
                </div>
              </div>
              
              <div className="p-12 flex-1 flex flex-col space-y-6">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className={`text-3xl font-black leading-tight tracking-tight ${isERP ? 'text-slate-900' : 'text-white'}`}>{product.name}</h3>
                    <p className="text-[10px] font-black text-emerald-500/60 uppercase tracking-[0.25em] mt-1">
                       {product.sellerName}
                    </p>
                  </div>
                  <div className="text-4xl font-black text-emerald-500 tracking-tighter">${product.price}</div>
                </div>

                <p className={`text-sm font-medium leading-relaxed ${isERP ? 'text-slate-500' : 'text-slate-400'}`}>
                  {product.description}
                </p>

                <div className={`pt-10 border-t flex items-center justify-between mt-auto ${isERP ? 'border-slate-100' : 'border-white/5'}`}>
                   <div className="flex items-center gap-3">
                      <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-emerald-500 border ${isERP ? 'bg-slate-50 border-slate-100' : 'bg-white/5 border-white/5'}`}>
                         <UserIcon size={20} />
                      </div>
                      <div>
                        <div className={`text-xs font-black uppercase tracking-widest ${isERP ? 'text-slate-900' : 'text-white'}`}>Verified</div>
                        <div className="text-[10px] font-bold text-slate-500 uppercase">Contract Trader</div>
                      </div>
                   </div>
                   
                   {activeUser ? (
                      <a 
                        href={`https://wa.me/${product.sellerPhone}?text=Hello%20${product.sellerName},%20I%20saw%20your%20listing%20on%20AgriMarket%20ZW%20and%20I%20am%20interested%20in%20${product.name}.`}
                        target="_blank" rel="noopener noreferrer"
                        className="bg-emerald-600 text-slate-950 px-10 py-4 rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-emerald-400 transition-all shadow-lg shadow-emerald-900/40"
                      >
                        Trade
                      </a>
                   ) : (
                      <button 
                        onClick={() => setAuthMode('login')}
                        className={`px-10 py-4 rounded-2xl font-black text-sm uppercase tracking-widest transition-all ${isERP ? 'bg-slate-100 text-slate-400' : 'bg-white/5 text-white/50 border border-white/5 hover:bg-white/10 hover:text-white'}`}
                      >
                        Sign In
                      </button>
                   )}
                </div>
              </div>
            </div>
          ))}

          {filtered.length === 0 && (
            <div className="col-span-full py-40 text-center space-y-6">
               <div className="w-24 h-24 bg-white/5 rounded-full flex items-center justify-center mx-auto text-slate-800">
                  <ShoppingBag size={48} />
               </div>
               <p className="text-slate-600 font-black uppercase tracking-[0.3em] text-xl">Exchange Floor Empty</p>
            </div>
          )}
        </div>
      </div>

      {authMode && (
        <MarketRegistration mode={authMode} setMode={setAuthMode} onClose={() => setAuthMode(null)} />
      )}

      {/* Manual Input System */}
      {isAdding && (
        <div className="fixed inset-0 bg-slate-950/90 backdrop-blur-md z-[200] flex items-center justify-center p-4">
          <div className="bg-white rounded-[48px] shadow-2xl w-full max-w-xl overflow-hidden animate-in zoom-in duration-300">
            <div className="p-12 bg-emerald-600 text-white text-center space-y-2 relative">
               <button onClick={() => setIsAdding(false)} className="absolute top-6 right-8 text-white/50 hover:text-white font-black text-xl">×</button>
               <h2 className="text-3xl font-black uppercase tracking-tighter">Publish Listing</h2>
               <p className="opacity-80 font-medium text-emerald-100 italic">Reach thousands of buyers instantly</p>
            </div>
            <form 
              onSubmit={(e) => {
                e.preventDefault();
                const formData = new FormData(e.currentTarget as HTMLFormElement);
                addMarketProduct({
                  name: formData.get('name') as string,
                  price: Number(formData.get('price')),
                  category: formData.get('category') as string,
                  description: formData.get('desc') as string,
                  sellerId: activeUser?.id || '',
                  sellerName: activeUser?.name || '',
                  sellerPhone: activeUser?.phone || '',
                  farmId: activeUser?.farmId || 'VISITOR',
                  date: new Date().toISOString(),
                  location: { lat: userLocation?.lat || 0, lng: userLocation?.lng || 0, name: userLocation?.name || 'Zimbabwe' },
                  imageUrl: formData.get('img') as string,
                  type: (formData.get('category') as string).includes('Transport') ? 'service' : 'product'
                });
                setIsAdding(false);
              }}
              className="p-12 space-y-4"
            >
              <input name="name" placeholder="Produce Name" required className="w-full p-4 rounded-2xl border-2 border-slate-50 outline-none focus:border-emerald-500 font-bold bg-slate-50" />
              <div className="grid grid-cols-2 gap-4">
                <input name="price" type="number" step="0.01" placeholder="Price (USD)" required className="w-full p-4 rounded-2xl border-2 border-slate-50 outline-none focus:border-emerald-500 font-bold bg-slate-50" />
                <select name="category" className="w-full p-4 rounded-2xl border-2 border-slate-100 outline-none focus:border-emerald-500 font-bold">
                   <option>Grains</option>
                   <option>Livestock</option>
                   <option>Vegetables</option>
                   <option>Poultry</option>
                   <option>Transport Services</option>
                   <option>Agri-Equipment</option>
                   <option>Consultancy</option>
                </select>
              </div>
              <textarea name="desc" placeholder="Product details and logistics..." required className="w-full p-4 h-32 rounded-2xl border-2 border-slate-50 outline-none focus:border-emerald-500 font-bold bg-slate-50" />
              <input name="img" placeholder="Real Product Image URL" required className="w-full p-4 rounded-2xl border-2 border-slate-50 outline-none focus:border-emerald-500 font-bold bg-slate-50" />
              <button className="w-full py-5 bg-slate-900 text-white rounded-[24px] font-black text-lg shadow-xl hover:bg-emerald-600 transition-all uppercase tracking-tighter">
                Publish Listing
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
