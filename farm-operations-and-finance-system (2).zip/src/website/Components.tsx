import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Building2, 
  ChevronRight, 
  CheckCircle2, 
  BarChart3, 
  ShieldCheck, 
  Smartphone, 
  Users,
  Globe,
  Zap,
  ArrowRight
} from 'lucide-react';

export const Navbar = () => (
  <nav className="fixed top-0 w-full z-50 bg-white/80 backdrop-blur-md border-b border-slate-100 px-6 py-4">
    <div className="max-w-7xl mx-auto flex justify-between items-center">
      <Link to="/" className="flex items-center gap-2 group">
        <div className="bg-emerald-600 p-2 rounded-lg group-hover:rotate-12 transition-transform">
          <Building2 size={24} className="text-white" />
        </div>
        <span className="text-xl font-black text-slate-800 tracking-tighter">FarmPro <span className="text-emerald-600 font-black">ZW</span></span>
      </Link>
      
      <div className="hidden lg:flex items-center gap-8 text-sm font-bold text-slate-600">
        <Link to="/features" className="hover:text-emerald-600 transition-colors">Features</Link>
        <Link to="/pricing" className="hover:text-emerald-600 transition-colors">Pricing</Link>
        <Link to="/marketplace" className="bg-emerald-600 text-white px-4 py-1.5 rounded-full hover:bg-emerald-700 transition-colors font-black uppercase text-[10px] tracking-widest shadow-lg shadow-emerald-900/10">Global Market</Link>
        <Link to="/about" className="hover:text-emerald-600 transition-colors">About</Link>
        <Link to="/security" className="hover:text-emerald-600 transition-colors">Security</Link>
      </div>

      <div className="flex items-center gap-4">
        <Link to="/app" className="bg-slate-900 text-white px-6 py-2.5 rounded-xl text-sm font-bold hover:bg-emerald-600 transition-all shadow-lg shadow-slate-900/10">
          Sign In
        </Link>
      </div>
    </div>
  </nav>
);

export const Footer = () => (
  <footer className="bg-slate-900 text-white pt-24 pb-12 px-6">
    <div className="max-w-7xl mx-auto">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-20">
        <div className="space-y-6">
          <Link to="/" className="flex items-center gap-2">
            <Building2 size={32} className="text-emerald-500" />
            <span className="text-2xl font-black tracking-tighter italic">FarmPro ZW</span>
          </Link>
          <p className="text-slate-400 text-sm leading-relaxed">
            Zimbabwe's most advanced agricultural enterprise platform. Revolutionizing farm management through real-time data and financial intelligence.
          </p>
        </div>
        
        <div>
          <h4 className="font-bold mb-6 text-emerald-500 uppercase text-xs tracking-widest">Platform</h4>
          <ul className="space-y-4 text-slate-400 text-sm font-medium">
            <li><Link to="/features" className="hover:text-white transition-colors">Core Modules</Link></li>
            <li><Link to="/pos-financials" className="hover:text-white transition-colors">POS & Accounting</Link></li>
            <li><Link to="/marketplace" className="hover:text-white transition-colors">Marketplace</Link></li>
            <li><Link to="/security" className="hover:text-white transition-colors">Cyber Security</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="font-bold mb-6 text-emerald-500 uppercase text-xs tracking-widest">Company</h4>
          <ul className="space-y-4 text-slate-400 text-sm font-medium">
            <li><Link to="/about" className="hover:text-white transition-colors">About ZW Agri</Link></li>
            <li><Link to="/roadmap" className="hover:text-white transition-colors">Product Roadmap</Link></li>
            <li><Link to="/success-stories" className="hover:text-white transition-colors">Success Stories</Link></li>
            <li><Link to="/developer" className="hover:text-white transition-colors">Developer Profile</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="font-bold mb-6 text-emerald-500 uppercase text-xs tracking-widest">Support & Legal</h4>
          <ul className="space-y-4 text-slate-400 text-sm font-medium">
            <li><Link to="/support" className="hover:text-white transition-colors">Technical Help</Link></li>
            <li><Link to="/faq" className="hover:text-white transition-colors">F.A.Q</Link></li>
            <li><Link to="/terms" className="hover:text-white transition-colors">Terms of Service</Link></li>
            <li><Link to="/privacy" className="hover:text-white transition-colors">Privacy Policy</Link></li>
          </ul>
        </div>
      </div>
      
      <div className="border-t border-slate-800 pt-8 flex flex-col md:row justify-between items-center gap-4 text-xs font-bold text-slate-500 uppercase tracking-widest">
        <span>© 2026 FarmPro ZW. All Rights Reserved.</span>
        <span>Developed by Tanaka T Tirivangani</span>
      </div>
    </div>
  </footer>
);

export const Home = () => (
  <div className="pt-20">
    {/* Hero Section */}
    <section className="relative h-[90vh] flex items-center overflow-hidden bg-slate-50">
      <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 items-center gap-12">
        <div className="z-10 space-y-8 animate-in fade-in slide-in-from-left-8 duration-700">
          <div className="inline-flex items-center gap-2 bg-emerald-100 text-emerald-700 px-4 py-1.5 rounded-full text-xs font-black uppercase tracking-widest">
            <Zap size={14} /> Built for Zimbabwean Farmers
          </div>
          <h1 className="text-6xl lg:text-8xl font-black text-slate-900 tracking-tight leading-[0.9]">
            The Future of <span className="text-emerald-600 italic">Agri-Business</span>
          </h1>
          <p className="text-lg text-slate-500 font-medium max-w-lg leading-relaxed">
            Move away from dusty notebooks. FarmPro ZW is a real-time ERP system that tracks your inventory, scales your sales, and secures your profits with bank-grade accounting.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Link to="/pricing" className="bg-emerald-600 text-white px-8 py-4 rounded-2xl font-black text-lg shadow-xl shadow-emerald-900/20 hover:bg-emerald-700 transition-all flex items-center justify-center gap-2 group">
              Start Free Trial <ArrowRight className="group-hover:translate-x-1 transition-transform" />
            </Link>
            <Link to="/features" className="bg-white border-2 border-slate-200 text-slate-800 px-8 py-4 rounded-2xl font-black text-lg hover:bg-slate-50 transition-all text-center">
              Explore Modules
            </Link>
          </div>
        </div>
        <div className="relative h-[600px] w-full hidden lg:block">
          <div className="absolute inset-0 bg-emerald-600/10 rounded-[60px] -rotate-3 animate-pulse"></div>
          <img 
            src="https://images.unsplash.com/photo-1625246333195-78d9c38ad449?auto=format&fit=crop&w=1200&q=80" 
            alt="Zimbabwean Farming"
            className="absolute inset-0 w-full h-full object-cover rounded-[60px] shadow-2xl rotate-3 transition-transform hover:rotate-0 duration-700"
          />
        </div>
      </div>
    </section>

    {/* Social Proof */}
    <section className="py-24 bg-white border-y border-slate-100">
      <div className="max-w-7xl mx-auto px-6">
        <p className="text-center text-xs font-black text-slate-400 uppercase tracking-[0.4em] mb-12">Trusted by 200+ Enterprise Farms Across Zimbabwe</p>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-12 grayscale opacity-40 hover:grayscale-0 hover:opacity-100 transition-all duration-500 items-center justify-items-center">
           <img src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=100&q=80" alt="Logo" />
           <img src="https://images.unsplash.com/photo-1444418185997-1145401101e0?auto=format&fit=crop&w=100&q=80" alt="Logo" />
           <img src="https://images.unsplash.com/photo-1518173946687-a4c8a9b746f5?auto=format&fit=crop&w=100&q=80" alt="Logo" />
           <img src="https://images.unsplash.com/photo-1495539406979-bf61750d38ad?auto=format&fit=crop&w=100&q=80" alt="Logo" />
           <img src="https://images.unsplash.com/photo-1500673922987-e212871fec22?auto=format&fit=crop&w=100&q=80" alt="Logo" />
           <img src="https://images.unsplash.com/photo-1531219432768-9f540ce91ef3?auto=format&fit=crop&w=100&q=80" alt="Logo" />
        </div>
      </div>
    </section>

    {/* Key Stats */}
    <section className="py-32 bg-emerald-900 text-white relative overflow-hidden">
       <div className="max-w-7xl mx-auto px-6 relative z-10 grid grid-cols-1 md:grid-cols-3 gap-12 text-center">
          <div className="space-y-4">
             <div className="text-6xl font-black text-emerald-400">$10M+</div>
             <p className="text-lg font-bold opacity-80 uppercase tracking-widest">Trade Processed</p>
          </div>
          <div className="space-y-4">
             <div className="text-6xl font-black text-emerald-400">1,500+</div>
             <p className="text-lg font-bold opacity-80 uppercase tracking-widest">Staff Accounts</p>
          </div>
          <div className="space-y-4">
             <div className="text-6xl font-black text-emerald-400">99.9%</div>
             <p className="text-lg font-bold opacity-80 uppercase tracking-widest">Uptime on Firebase</p>
          </div>
       </div>
       <div className="absolute inset-0 opacity-10">
          <img src="https://images.unsplash.com/photo-1464226184884-fa280b87c399?auto=format&fit=crop&w=1920&q=80" className="w-full h-full object-cover" />
       </div>
    </section>
  </div>
);

export const FeaturePage = () => (
  <div className="pt-32 pb-24 px-6 bg-slate-50 min-h-screen">
    <div className="max-w-7xl mx-auto space-y-24">
      <div className="text-center max-w-3xl mx-auto space-y-6">
        <h2 className="text-5xl font-black text-slate-900 tracking-tight leading-none">Complete Control in One Dashboard</h2>
        <p className="text-lg text-slate-500 font-medium leading-relaxed">Our modular architecture allows you to scale from a single greenhouse to a multi-farm agricultural empire.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {[
          { icon: Smartphone, title: 'Multi-Item POS', desc: 'Custom thermal receipt printer integration with EcoCash and InnBucks support.', img: 'https://images.unsplash.com/photo-1556742044-3c52d6e88c62?auto=format&fit=crop&w=600&q=80' },
          { icon: BarChart3, title: 'Live Accounting', desc: 'Automated Trading P&L, Balance Sheets, and General Ledgers for audit readiness.', img: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=600&q=80' },
          { icon: ShieldCheck, title: 'Secure Auditing', desc: 'Every login and every dollar tracked with permanent, unchangeable audit logs.', img: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=600&q=80' },
          { icon: Building2, title: 'Department Isolation', desc: 'Separate your Poultry, Crops, and Livestock with dedicated profit tracking.', img: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=600&q=80' },
          { icon: Users, title: 'Staff Management', desc: 'Assign unique passwords and restricted access levels for every farm employee.', img: 'https://images.unsplash.com/photo-1589923188900-85dae523342b?auto=format&fit=crop&w=600&q=80' },
          { icon: Globe, title: 'Cloud Sync', desc: 'Manage your farm from Harare, Bulawayo, or London with real-time cloud data.', img: 'https://images.unsplash.com/photo-1508962914676-134849a727f0?auto=format&fit=crop&w=600&q=80' }
        ].map((f, i) => (
          <div key={i} className="bg-white rounded-[40px] overflow-hidden border border-slate-100 shadow-sm group hover:shadow-xl transition-all">
            <div className="h-48 overflow-hidden">
               <img src={f.img} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" alt={f.title} />
            </div>
            <div className="p-10 space-y-4">
              <div className="bg-emerald-50 w-14 h-14 rounded-2xl flex items-center justify-center text-emerald-600">
                <f.icon size={28} />
              </div>
              <h3 className="text-2xl font-black text-slate-800 tracking-tight">{f.title}</h3>
              <p className="text-slate-500 font-medium text-sm leading-relaxed">{f.desc}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  </div>
);

export const PricingPage = () => (
  <div className="pt-32 pb-24 px-6 min-h-screen">
    <div className="max-w-7xl mx-auto space-y-16">
      <div className="text-center max-w-2xl mx-auto space-y-4">
        <h2 className="text-6xl font-black text-slate-900 tracking-tighter">Enterprise Plans</h2>
        <p className="text-xl text-slate-500 font-medium italic">High-precision tools for professional agriculture.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {[
          { name: 'Starter Plan', price: 'FREE', color: 'slate', features: ['1 Department', 'Local Data', 'Basic POS', 'Email Support'] },
          { name: 'Professional', price: '$45', color: 'emerald', features: ['Unlimited Departments', 'Cloud Syncing', 'Full Accounting Suite', 'Paynow Integration', 'Excel/CSV Exports'], hot: true },
          { name: 'Enterprise', price: '$150', color: 'slate', features: ['Multi-Farm Access', 'Personal Account Manager', 'Custom API Access', 'Staff Training', 'Priority Bug Fixes'] }
        ].map((p, i) => (
          <div key={i} className={`p-12 rounded-[50px] border-2 transition-all relative ${p.hot ? 'border-emerald-500 bg-white shadow-2xl scale-105 z-10' : 'border-slate-100 bg-slate-50 shadow-sm'}`}>
            {p.hot && <span className="absolute -top-6 left-1/2 -translate-x-1/2 bg-emerald-600 text-white px-6 py-2 rounded-full font-black text-xs uppercase tracking-widest">Recommended</span>}
            <h3 className="text-xl font-black text-slate-400 uppercase tracking-widest mb-6">{p.name}</h3>
            <div className="flex items-baseline gap-2 mb-10">
              <span className="text-6xl font-black text-slate-900">{p.price}</span>
              {p.price !== 'FREE' && <span className="text-slate-400 font-bold tracking-widest">/30 DAYS</span>}
            </div>
            <ul className="space-y-6 mb-12">
              {p.features.map((f, j) => (
                <li key={j} className="flex items-center gap-3 font-bold text-slate-600 text-sm italic">
                  <CheckCircle2 size={18} className="text-emerald-500 shrink-0" /> {f}
                </li>
              ))}
            </ul>
            <Link 
              to="/app" 
              className={`w-full py-5 rounded-3xl font-black text-lg transition-all text-center block ${p.hot ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-900/20 hover:bg-emerald-700' : 'bg-white border border-slate-200 text-slate-800 hover:bg-slate-50'}`}
            >
               {p.price === 'FREE' ? 'Access System' : 'Upgrade Farm'}
            </Link>
          </div>
        ))}
      </div>
    </div>
  </div>
);
